/**
 * Recipes — a cookbook for aCelery.
 *
 * Screens (state, not DOM rebuilding):
 *   list        browse / search / filter recipes, add new, go to categories
 *   recipe      one recipe: name, category and tabs for
 *               Ingredients · Procedure · Photos · Notes · Source
 *   categories  maintain the category table
 *
 * Data: db/recipes.db
 *   category(id, name)
 *   recipe(id, name, category -> category.id, ingredients, procedure, notes,
 *          source, created, updated)
 *   photo(id, recipe -> recipe.id, path, created)   files in files/Recipes/photos
 */

import { openDB } from "acelery/sql.js";
import * as file from "acelery/file.js";
import { shrinkImage } from "acelery/picker.js";
import { closeApp } from "acelery/export.js";
import {
  html, render, useState, useEffect,
  Navbar, Container, Alert, Button, Badge, ListGroup, Modal, Tab, Tabs,
  FileButton, Spinner,
} from "acelery/ui.js";

const PHOTO_DIR = "Recipes/photos";

const DEFAULT_CATEGORIES = [
  "Starters", "Soups", "Salads", "Main courses", "Sides",
  "Breads", "Desserts", "Drinks", "Sauces",
];

/* ------------------------------------------------------------------ data */

async function openDatabase() {
  const db = await openDB("recipes.db");
  await db.exec(
    "create table if not exists category (" +
      " id integer primary key," +
      " name text not null unique collate nocase)",
  );
  await db.exec(
    "create table if not exists recipe (" +
      " id integer primary key," +
      " name text not null," +
      " category integer," +
      " ingredients text default ''," +
      " procedure text default ''," +
      " notes text default ''," +
      " source text default ''," +
      " created text, updated text)",
  );
  await db.exec(
    "create table if not exists photo (" +
      " id integer primary key," +
      " recipe integer not null," +
      " path text not null," +
      " created text)",
  );
  await db.exec("create index if not exists photo_recipe on photo(recipe)");
  await db.exec("create index if not exists recipe_category on recipe(category)");

  const { n } = await db.selectOne("select count(*) as n from category");
  if (!n) {
    for (const name of DEFAULT_CATEGORIES) {
      await db.insert("insert into category (name) values (?)", [name]);
    }
  }
  return db;
}

function loadCategories(db) {
  return db.select(
    "select c.id, c.name, count(r.id) as n" +
      " from category c left join recipe r on r.category = c.id" +
      " group by c.id order by c.name collate nocase",
  );
}

async function deletePhotoFile(path) {
  try {
    const handle = await file.open(path);
    await handle.delete();
  } catch (e) {
    console.warn("Could not delete", path, e.message);
  }
}

/** Adds https:// to "www.site.com/x" so the link works; leaves real URLs alone. */
function normalizeUrl(url) {
  const u = (url || "").trim();
  if (!u) return "";
  if (/^[a-z][a-z0-9+.-]*:/i.test(u)) return u;
  return "https://" + u;
}

const niceError = (e) =>
  /unique/i.test(e.message)
    ? "A category with that name already exists."
    : e.message;

/* ------------------------------------------------------------ small parts */

/** A confirmation dialog. state = { text, ok, variant, action } or null. */
function Confirm({ state, onClose }) {
  return html`
    <${Modal} show=${!!state} onHide=${onClose} centered>
      <${Modal.Body}>${state ? state.text : ""}<//>
      <${Modal.Footer}>
        <${Button} variant="secondary" onClick=${onClose}>Cancel<//>
        <${Button} variant=${(state && state.variant) || "danger"}
          onClick=${async () => {
            const action = state.action;
            onClose();
            await action();
          }}>${(state && state.ok) || "OK"}<//>
      <//>
    <//>`;
}

function CategorySelect({ categories, value, onChange, allLabel, className }) {
  return html`
    <select class=${"form-select " + (className || "")}
      value=${value == null ? "" : String(value)}
      onChange=${(e) => onChange(e.target.value)}>
      <option value="">${allLabel}</option>
      ${categories.map((c) => html`
        <option key=${c.id} value=${String(c.id)}>${c.name}</option>`)}
    </select>`;
}

/* ------------------------------------------------------------ list screen */

function RecipeList({ db, categories, filter, setFilter, onOpen, onNew, onCategories }) {
  const [rows, setRows] = useState(null);
  const [error, setError] = useState(null);
  const { q, cat } = filter;

  useEffect(() => {
    let live = true;
    const where = [];
    const args = [];
    const text = q.trim();
    if (text) {
      const p = `%${text}%`;
      where.push("(r.name like ? or r.ingredients like ? or r.notes like ?)");
      args.push(p, p, p);
    }
    if (cat === "none") where.push("r.category is null");
    else if (cat) {
      where.push("r.category = ?");
      args.push(Number(cat));
    }
    const sql =
      "select r.id, r.name, c.name as cname," +
      " (select p.path from photo p where p.recipe = r.id order by p.id limit 1) as thumb" +
      " from recipe r left join category c on c.id = r.category" +
      (where.length ? " where " + where.join(" and ") : "") +
      " order by r.name collate nocase";
    db.select(sql, args).then(
      (r) => live && setRows(r),
      (e) => live && setError(e.message),
    );
    return () => { live = false; };
  }, [db, q, cat]);

  const total = categories.reduce((s, c) => s + c.n, 0);

  return html`
    <div class="d-flex gap-2 mb-2">
      <${Button} variant="primary" className="flex-fill" onClick=${onNew}>
        + New recipe
      <//>
      <${Button} variant="outline-secondary" onClick=${onCategories}>
        Categories
      <//>
    </div>

    <input type="search" class="form-control mb-2"
      placeholder="Search name, ingredients, notes…"
      value=${q}
      onInput=${(e) => setFilter({ ...filter, q: e.target.value })} />

    <select class="form-select mb-3" value=${cat}
      onChange=${(e) => setFilter({ ...filter, cat: e.target.value })}>
      <option value="">All categories</option>
      ${categories.map((c) => html`
        <option key=${c.id} value=${String(c.id)}>${c.name} (${c.n})</option>`)}
      <option value="none">— Uncategorised —</option>
    </select>

    ${error ? html`<${Alert} variant="danger">${error}<//>` : null}

    ${rows === null
      ? html`<div class="text-center py-4"><${Spinner} animation="border" /></div>`
      : rows.length === 0
        ? html`<${Alert} variant="secondary">
            ${q || cat
              ? "No recipes match."
              : "No recipes yet. Tap “New recipe” to add your first one."}
          <//>`
        : html`
          <div class="small text-body-secondary mb-1">
            ${rows.length} recipe${rows.length === 1 ? "" : "s"}
          </div>
          <${ListGroup} className="mb-4">
            ${rows.map((r) => html`
              <${ListGroup.Item} key=${r.id} action
                className="d-flex align-items-center py-2"
                onClick=${() => onOpen(r.id)}>
                ${r.thumb
                  ? html`<img src=${file.url(r.thumb)} alt=""
                      class="rounded me-3 recipe-thumb" />`
                  : html`<div class="rounded me-3 recipe-thumb-empty">🍽️</div>`}
                <div class="flex-grow-1 text-truncate">
                  <div class="fw-semibold text-truncate">${r.name}</div>
                  ${r.cname
                    ? html`<${Badge} bg="secondary" className="fw-normal">${r.cname}<//>`
                    : html`<span class="small text-body-secondary">Uncategorised</span>`}
                </div>
                <span class="text-body-secondary ms-2">›</span>
              <//>`)}
          <//>`}
  `;
}

/* ------------------------------------------------------------ photos tab */

function Photos({ db, recipeId, onSaveFirst }) {
  const [photos, setPhotos] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [viewing, setViewing] = useState(null);
  const [armed, setArmed] = useState(false);

  async function load() {
    if (!recipeId) return setPhotos([]);
    setPhotos(await db.select(
      "select id, path from photo where recipe = ? order by id", [recipeId]));
  }

  useEffect(() => {
    load().catch((e) => setError(e.message));
  }, [recipeId]);

  async function add(files) {
    if (!files || !files.length) return;
    setError(null);
    setBusy(true);
    try {
      let n = 0;
      for (const f of files) {
        const blob = await shrinkImage(f, { maxSide: 1600 });
        const path = `${PHOTO_DIR}/${recipeId}_${Date.now()}_${n++}.jpg`;
        await file.writeBytes(path, blob);
        await db.insert(
          "insert into photo (recipe, path, created) values (?, ?, ?)",
          [recipeId, path, new Date().toISOString()]);
      }
      await load();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function remove(p) {
    try {
      await deletePhotoFile(p.path);
      await db.exec("delete from photo where id = ?", [p.id]);
      setViewing(null);
      setArmed(false);
      await load();
    } catch (e) {
      setError(e.message);
    }
  }

  if (!recipeId) {
    return html`
      <${Alert} variant="info">
        Save the recipe once before adding photos.
        <div class="mt-2">
          <${Button} variant="primary" size="sm" onClick=${onSaveFirst}>Save now<//>
        </div>
      <//>`;
  }

  return html`
    <div class="d-flex flex-wrap gap-2 mb-3">
      <${FileButton} accept="image/*" capture="environment" disabled=${busy}
        onFiles=${add}>📷 Camera<//>
      <${FileButton} accept="image/*" multiple variant="outline-primary"
        disabled=${busy} onFiles=${add}>🖼️ Gallery<//>
      ${busy ? html`<${Spinner} animation="border" size="sm" className="align-self-center" />` : null}
    </div>

    ${error ? html`<${Alert} variant="danger">${error}<//>` : null}

    ${photos === null
      ? null
      : photos.length === 0
        ? html`<p class="text-body-secondary">No photos yet.</p>`
        : html`
          <div class="row g-2">
            ${photos.map((p) => html`
              <div class="col-4 col-md-3 photo-cell" key=${p.id}>
                <div class="ratio ratio-1x1">
                  <img src=${file.url(p.path)} alt="" class="rounded w-100 h-100"
                    onClick=${() => { setArmed(false); setViewing(p); }} />
                </div>
              </div>`)}
          </div>`}

    <${Modal} show=${!!viewing} onHide=${() => setViewing(null)} centered size="lg">
      <${Modal.Body} className="p-2">
        ${viewing
          ? html`<img src=${file.url(viewing.path)} alt="" class="photo-full rounded" />`
          : null}
      <//>
      <${Modal.Footer}>
        <${Button} variant=${armed ? "danger" : "outline-danger"}
          onClick=${() => (armed ? remove(viewing) : setArmed(true))}>
          ${armed ? "Tap again to delete" : "Delete"}
        <//>
        <${Button} variant="secondary" onClick=${() => setViewing(null)}>Close<//>
      <//>
    <//>`;
}

/* ------------------------------------------------------------ recipe screen */

const BLANK = {
  id: null, name: "", category: null,
  ingredients: "", procedure: "", notes: "", source: "",
};

function clean(r) {
  return {
    id: r.id,
    name: r.name || "",
    category: r.category == null ? null : Number(r.category),
    ingredients: r.ingredients || "",
    procedure: r.procedure || "",
    notes: r.notes || "",
    source: r.source || "",
  };
}

function RecipeEditor({ db, id, categories, onClose, initialCategory }) {
  const [rec, setRec] = useState(null);
  const [orig, setOrig] = useState(null);
  const [tab, setTab] = useState("ingredients");
  const [error, setError] = useState(null);
  const [flash, setFlash] = useState(null);
  const [confirm, setConfirm] = useState(null);

  useEffect(() => {
    let live = true;
    (async () => {
      let r;
      if (id) {
        const row = await db.selectOne(
          "select id, name, category, ingredients, procedure, notes, source" +
            " from recipe where id = ?", [id]);
        if (!row) throw new Error("That recipe no longer exists.");
        r = clean(row);
      } else {
        r = { ...BLANK, category: initialCategory || null };
      }
      if (live) { setRec(r); setOrig(r); }
    })().catch((e) => live && setError(e.message));
    return () => { live = false; };
  }, [db, id]);

  if (error && !rec) return html`
    <${Alert} variant="danger">${error}<//>
    <${Button} onClick=${onClose}>Back<//>`;
  if (!rec) return html`<div class="text-center py-4"><${Spinner} animation="border" /></div>`;

  const dirty = JSON.stringify(rec) !== JSON.stringify(orig);
  const set = (field) => (e) => setRec({ ...rec, [field]: e.target.value });

  async function save() {
    setError(null);
    const name = rec.name.trim();
    if (!name) {
      setError("Give the recipe a name.");
      return null;
    }
    try {
      const source = normalizeUrl(rec.source);
      const now = new Date().toISOString();
      const vals = [name, rec.category, rec.ingredients, rec.procedure, rec.notes, source];
      let rid = rec.id;
      if (rid) {
        await db.exec(
          "update recipe set name = ?, category = ?, ingredients = ?, procedure = ?," +
            " notes = ?, source = ?, updated = ? where id = ?",
          [...vals, now, rid]);
      } else {
        rid = await db.insert(
          "insert into recipe (name, category, ingredients, procedure, notes, source," +
            " created, updated) values (?, ?, ?, ?, ?, ?, ?, ?)",
          [...vals, now, now]);
      }
      const saved = { ...rec, id: rid, name, source };
      setRec(saved);
      setOrig(saved);
      setFlash("Saved");
      setTimeout(() => setFlash(null), 1500);
      return rid;
    } catch (e) {
      setError(e.message);
      return null;
    }
  }

  function back() {
    if (!dirty) return onClose();
    setConfirm({
      text: "You have unsaved changes. Discard them?",
      ok: "Discard",
      action: onClose,
    });
  }

  function askDelete() {
    setConfirm({
      text: `Delete “${rec.name}” and all its photos? This cannot be undone.`,
      ok: "Delete",
      action: async () => {
        try {
          const photos = await db.select("select path from photo where recipe = ?", [rec.id]);
          for (const p of photos) await deletePhotoFile(p.path);
          await db.exec("delete from photo where recipe = ?", [rec.id]);
          await db.exec("delete from recipe where id = ?", [rec.id]);
          onClose();
        } catch (e) {
          setError(e.message);
        }
      },
    });
  }

  const textTab = (field, placeholder) => html`
    <textarea class="form-control recipe-text" value=${rec[field]}
      placeholder=${placeholder} onInput=${set(field)} />`;

  const url = normalizeUrl(rec.source);

  return html`
    <div class="editor-bar d-flex align-items-center gap-2 py-2 mb-3">
      <${Button} variant="outline-secondary" onClick=${back}>‹ Back<//>
      <div class="flex-grow-1 text-truncate fw-semibold">
        ${rec.id ? rec.name || "Recipe" : "New recipe"}
      </div>
      ${flash ? html`<${Badge} bg="success">${flash}<//>` : null}
      <${Button} variant="primary" disabled=${!dirty} onClick=${save}>Save<//>
    </div>

    ${error ? html`<${Alert} variant="danger" dismissible onClose=${() => setError(null)}>${error}<//>` : null}

    <input class="form-control form-control-lg mb-2" placeholder="Recipe name"
      value=${rec.name} onInput=${set("name")} />

    <${CategorySelect} categories=${categories} className="mb-3"
      value=${rec.category} allLabel="— No category —"
      onChange=${(v) => setRec({ ...rec, category: v ? Number(v) : null })} />

    <${Tabs} activeKey=${tab} onSelect=${(k) => setTab(k)}
      className="recipe-tabs mb-3" mountOnEnter>
      <${Tab} eventKey="ingredients" title="Ingredients">
        ${textTab("ingredients", "One ingredient per line, e.g.\n500 g flour\n2 eggs")}
      <//>
      <${Tab} eventKey="procedure" title="Procedure">
        ${textTab("procedure", "1. Preheat the oven…\n2. …")}
      <//>
      <${Tab} eventKey="photos" title="Photos">
        <${Photos} db=${db} recipeId=${rec.id} onSaveFirst=${save} />
      <//>
      <${Tab} eventKey="notes" title="Notes">
        ${textTab("notes", "Variations, tips, who liked it…")}
      <//>
      <${Tab} eventKey="source" title="Source">
        <label class="form-label">Source URL</label>
        <input type="url" inputmode="url" class="form-control mb-3"
          placeholder="https://…" value=${rec.source} onInput=${set("source")}
          autocapitalize="off" autocorrect="off" spellcheck=${false} />
        ${url
          ? html`<a class="btn btn-outline-primary" href=${url}
              target="_blank" rel="noopener noreferrer">Open link ↗</a>`
          : null}
      <//>
    <//>

    ${rec.id
      ? html`<div class="mt-4 mb-5">
          <${Button} variant="outline-danger" size="sm" onClick=${askDelete}>
            Delete recipe
          <//>
        </div>`
      : null}

    <${Confirm} state=${confirm} onClose=${() => setConfirm(null)} />`;
}

/* ------------------------------------------------------------ categories */

function Categories({ db, categories, reload, onBack }) {
  const [newName, setNewName] = useState("");
  const [editing, setEditing] = useState(null); // { id, name }
  const [error, setError] = useState(null);
  const [confirm, setConfirm] = useState(null);

  async function run(work) {
    setError(null);
    try {
      await work();
      await reload();
    } catch (e) {
      setError(niceError(e));
    }
  }

  const add = () => run(async () => {
    const name = newName.trim();
    if (!name) return;
    await db.insert("insert into category (name) values (?)", [name]);
    setNewName("");
  });

  const rename = () => run(async () => {
    const name = editing.name.trim();
    if (!name) throw new Error("A category needs a name.");
    await db.exec("update category set name = ? where id = ?", [name, editing.id]);
    setEditing(null);
  });

  const askRemove = (c) => setConfirm({
    text: c.n
      ? `Delete “${c.name}”? Its ${c.n} recipe${c.n === 1 ? "" : "s"} will become uncategorised.`
      : `Delete “${c.name}”?`,
    ok: "Delete",
    action: () => run(async () => {
      await db.exec("update recipe set category = null where category = ?", [c.id]);
      await db.exec("delete from category where id = ?", [c.id]);
    }),
  });

  return html`
    <div class="d-flex align-items-center gap-2 mb-3">
      <${Button} variant="outline-secondary" onClick=${onBack}>‹ Recipes<//>
      <h5 class="mb-0 flex-grow-1">Categories</h5>
    </div>

    ${error ? html`<${Alert} variant="danger" dismissible onClose=${() => setError(null)}>${error}<//>` : null}

    <div class="input-group mb-3">
      <input class="form-control" placeholder="New category" value=${newName}
        onInput=${(e) => setNewName(e.target.value)}
        onKeyDown=${(e) => e.key === "Enter" && add()} />
      <${Button} variant="primary" disabled=${!newName.trim()} onClick=${add}>Add<//>
    </div>

    <${ListGroup} className="mb-5">
      ${categories.length === 0
        ? html`<${ListGroup.Item} className="text-body-secondary">No categories.<//>`
        : categories.map((c) => html`
          <${ListGroup.Item} key=${c.id} className="d-flex align-items-center gap-2">
            ${editing && editing.id === c.id
              ? html`
                <input class="form-control" value=${editing.name}
                  onInput=${(e) => setEditing({ ...editing, name: e.target.value })}
                  onKeyDown=${(e) => e.key === "Enter" && rename()} />
                <${Button} size="sm" variant="primary" onClick=${rename}>Save<//>
                <${Button} size="sm" variant="secondary" onClick=${() => setEditing(null)}>✕<//>`
              : html`
                <div class="flex-grow-1">
                  ${c.name}
                  <span class="text-body-secondary small ms-1">(${c.n})</span>
                </div>
                <${Button} size="sm" variant="outline-secondary"
                  onClick=${() => setEditing({ id: c.id, name: c.name })}>Rename<//>
                <${Button} size="sm" variant="outline-danger"
                  onClick=${() => askRemove(c)}>Delete<//>`}
          <//>`)}
    <//>

    <${Confirm} state=${confirm} onClose=${() => setConfirm(null)} />`;
}

/* ------------------------------------------------------------ shell */

function App() {
  const [db, setDb] = useState(null);
  const [failure, setFailure] = useState(null);
  const [categories, setCategories] = useState([]);
  const [screen, setScreen] = useState({ name: "list" });
  const [filter, setFilter] = useState({ q: "", cat: "" });

  const reloadCategories = async (d = db) => setCategories(await loadCategories(d));

  useEffect(() => {
    let live = true;
    openDatabase()
      .then(async (opened) => {
        const cats = await loadCategories(opened);
        if (live) { setDb(opened); setCategories(cats); }
      })
      .catch((e) => live && setFailure(e.message));
    return () => { live = false; };
  }, []);

  const toList = () => {
    reloadCategories().catch((e) => setFailure(e.message));
    setScreen({ name: "list" });
    window.scrollTo(0, 0);
  };
  const go = (s) => { setScreen(s); window.scrollTo(0, 0); };

  let body;
  if (failure) body = html`<${Alert} variant="danger">${failure}<//>`;
  else if (!db) body = html`<div class="text-center py-5"><${Spinner} animation="border" /></div>`;
  else if (screen.name === "recipe") body = html`
    <${RecipeEditor} key=${screen.id || "new"} db=${db} id=${screen.id}
      categories=${categories} onClose=${toList}
      initialCategory=${filter.cat && filter.cat !== "none" ? Number(filter.cat) : null} />`;
  else if (screen.name === "categories") body = html`
    <${Categories} db=${db} categories=${categories}
      reload=${() => reloadCategories()} onBack=${toList} />`;
  else body = html`
    <${RecipeList} db=${db} categories=${categories}
      filter=${filter} setFilter=${setFilter}
      onOpen=${(id) => go({ name: "recipe", id })}
      onNew=${() => go({ name: "recipe", id: null })}
      onCategories=${() => go({ name: "categories" })} />`;

  return html`
    ${screen.name === "recipe"
      ? null
      : html`
        <${Navbar} className="bg-body-tertiary mb-3">
          <${Container} fluid>
            <${Navbar.Brand} href="#" onClick=${(e) => { e.preventDefault(); toList(); }}>
              🍳 Recipes
            <//>
            <${Button} variant="outline-secondary" size="sm" onClick=${closeApp}>Exit<//>
          <//>
        <//>`}
    <${Container} fluid style=${{ maxWidth: "900px" }}>
      ${body}
    <//>`;
}

export default function main() {
  render(html`<${App} />`, document.body);
}
