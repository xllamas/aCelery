/**
 * Books — the books I have read.
 *
 * Screens (state, not DOM rebuilding):
 *   list        browse, search and filter the library; add a book; categories
 *   book        one book: cover, bibliography, notes; edit or delete
 *   editor      add or change a book, with an ISBN lookup on OpenLibrary
 *   categories  maintain the category table
 *
 * Data: db/books.db
 *   category(id, name)
 *   book(id, title, subtitle, authors, publisher, published, pub_year, pages,
 *        language, subjects, isbn, olid, category -> category.id, rating,
 *        read_on, notes, cover, created, updated)
 *
 * Covers live in files/Books/covers and book.cover holds the path, not the
 * bytes. A cover can be photographed, chosen from the gallery, or downloaded
 * from OpenLibrary with the rest of the record. A cover file is only deleted
 * once the change it belongs to has been saved, so that discarding an edit
 * never leaves a record pointing at a file that has gone.
 */

import { openDB } from "acelery/sql.js";
import * as file from "acelery/file.js";
import * as http from "acelery/http.js";
import { closeApp } from "acelery/export.js";
import {
  html, render, useState, useEffect,
  Navbar, Container, Alert, Button, Badge, ListGroup, Modal, Spinner,
  FileButton, ImageCropper, Row, Col,
} from "acelery/ui.js";

const COVER_DIR = "Books/covers";

const DEFAULT_CATEGORIES = [
  "Fiction", "Non-fiction", "Biography", "History", "Science",
  "Science fiction", "Crime", "Poetry", "Reference", "Travel",
];

const SORTS = {
  title: "b.title collate nocase",
  author: "b.authors collate nocase",
  added: "b.created desc",
  year: "b.pub_year desc",
  read: "b.read_on desc",
  rating: "b.rating desc",
};

/* ------------------------------------------------------------------ data */

async function openDatabase() {
  const db = await openDB("books.db");

  await db.exec(
    "create table if not exists category (" +
      " id integer primary key," +
      " name text not null unique collate nocase)",
  );
  await db.exec(
    "create table if not exists book (" +
      " id integer primary key," +
      " title text not null," +
      " subtitle text default ''," +
      " authors text default ''," +
      " publisher text default ''," +
      " published text default ''," +
      " pub_year integer," +
      " pages integer," +
      " language text default ''," +
      " subjects text default ''," +
      " isbn text default ''," +
      " olid text default ''," +
      " category integer references category(id) on delete set null," +
      " rating integer," +
      " read_on text default ''," +
      " notes text default ''," +
      " cover text default ''," +
      " created text, updated text)",
  );
  await db.exec("create index if not exists book_category on book(category)");
  await db.exec("create index if not exists book_read_on on book(read_on)");

  const { n } = await db.selectOne("select count(*) as n from category");
  if (!n) {
    for (const name of DEFAULT_CATEGORIES) {
      await db.insert("insert into category (name) values (?)", [name]);
    }
  }
  return db;
}

function loadCategories(db) {
  return db.select(
    "select c.id, c.name, count(b.id) as n" +
      " from category c left join book b on b.category = c.id" +
      " group by c.id order by c.name collate nocase",
  );
}

/* ------------------------------------------------------- covers and files */

async function deleteCover(path) {
  if (!path || path.indexOf(COVER_DIR + "/") !== 0) return;
  try {
    const handle = await file.open(path);
    await handle.delete();
  } catch (e) {
    console.warn("Could not delete", path, e.message);
  }
}

async function storeCover(blob) {
  const path =
    COVER_DIR + "/" + Date.now() + "-" + Math.floor(Math.random() * 1000) + ".jpg";
  await file.writeBytes(path, blob);
  return path;
}

/** A phone on a bad network can leave a request hanging for ever, and the
    screen would then stay on "Looking…". Every call is bounded. */
function within(promise, ms, what) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(
      () => reject(new Error(what + " did not answer")), ms)),
  ]);
}

/** OpenLibrary answers a missing cover with a 43-byte placeholder, so the
    bytes themselves have to look like an image before they are stored. */
async function looksLikeImage(blob) {
  if (!blob || blob.size < 2000) return false;
  const head = new Uint8Array(await blob.slice(0, 4).arrayBuffer());
  if (head[0] === 0xff && head[1] === 0xd8) return true;            // JPEG
  if (head[0] === 0x89 && head[1] === 0x50) return true;            // PNG
  if (head[0] === 0x47 && head[1] === 0x49) return true;            // GIF
  return false;
}

/** The page's own fetch first, because it hands back the bytes as they are;
    aCelery's HTTP client is the fallback. */
async function fetchImageBlob(url) {
  try {
    const response = await within(fetch(url), 20000, "The cover");
    if (response.ok) {
      const blob = await response.blob();
      if (await looksLikeImage(blob)) return blob;
    }
  } catch (e) {
    /* not fatal: try the phone's HTTP stack */
  }
  try {
    const text = await within(http.get(url), 20000, "The cover");
    if (typeof text !== "string" || text.length < 2000) return null;
    const bytes = new Uint8Array(text.length);
    for (let i = 0; i < text.length; i++) bytes[i] = text.charCodeAt(i) & 0xff;
    const blob = new Blob([bytes], { type: "image/jpeg" });
    return (await looksLikeImage(blob)) ? blob : null;
  } catch (e) {
    return null;
  }
}

/* ------------------------------------------------------- the OpenLibrary API
 *
 * Three free endpoints, tried in turn, so that a lookup still works when one
 * of them is having a bad day — /api/books answers 404 from some networks:
 *
 *   /api/books?…&jscmd=data   everything, cover URLs included, in one call
 *   /isbn/<isbn>.json         the very edition that carries this ISBN
 *   /search.json?isbn=…       a last resort, checked against its ISBN list
 *
 * No key and no account. Every answer is JSON.
 */

const OL_BOOKS = "https://openlibrary.org/api/books";
const OL_SEARCH = "https://openlibrary.org/search.json";

const digitsOnly = (raw) => (raw || "").replace(/[^0-9Xx]/g, "").toUpperCase();

function yearOf(text) {
  const m = /(\d{4})/.exec(text || "");
  return m ? Number(m[1]) : null;
}

const LANGUAGES = {
  eng: "English", spa: "Spanish", fre: "French", ger: "German", ita: "Italian",
  por: "Portuguese", dut: "Dutch", rus: "Russian", jpn: "Japanese",
  chi: "Chinese", ara: "Arabic", pol: "Polish", swe: "Swedish", dan: "Danish",
  cat: "Catalan", heb: "Hebrew", tur: "Turkish", wel: "Welsh", gla: "Gaelic",
};

const langName = (code) =>
  !code ? "" : (LANGUAGES[String(code).toLowerCase()] || String(code));

const namesOf = (list, howMany) =>
  (list || []).slice(0, howMany).map((x) => (typeof x === "string" ? x : x.name))
    .filter(Boolean).join("; ");

/** One JSON document, however the phone has to ask for it. */
async function fetchJson(url) {
  try {
    const value = await within(http.getJson(url), 12000, "OpenLibrary");
    if (typeof value === "string") {
      return value.trim() ? JSON.parse(value) : null;
    }
    return value || null;
  } catch (e) {
    /* the page's own fetch may still get through */
  }
  try {
    const response = await within(fetch(url), 12000, "OpenLibrary");
    if (!response.ok) return null;
    return await response.json();
  } catch (e) {
    return null;
  }
}

/** The whole bibliography, with cover URLs, in a single call. */
async function fromDataApi(isbn) {
  const json = await fetchJson(
    OL_BOOKS + "?bibkeys=ISBN:" + isbn + "&format=json&jscmd=data",
  );
  const rec = json && json["ISBN:" + isbn];
  if (!rec || !rec.title) return null;
  const cover = rec.cover || {};
  return {
    title: rec.title,
    subtitle: rec.subtitle || "",
    authors: namesOf(rec.authors, 4),
    publisher: namesOf(rec.publishers, 3),
    published: rec.publish_date || "",
    pub_year: yearOf(rec.publish_date),
    pages: rec.number_of_pages || null,
    language: "",
    subjects: namesOf(rec.subjects, 12),
    isbn,
    olid: rec.key || "",
    coverUrl: cover.large || cover.medium || cover.small || "",
  };
}

/** The edition record for this ISBN, its authors, and its work's subjects.
    Author names are not in the edition: only their keys are, either as
    `authors` on the edition, a single `author`, or on the work. */
async function fromEditionApi(isbn) {
  const ed = await fetchJson("https://openlibrary.org/isbn/" + isbn + ".json");
  if (!ed || !ed.title) return null;

  const authorKeys = [];
  for (const a of ed.authors || []) if (a && a.key) authorKeys.push(a.key);
  if (ed.author && ed.author.key) authorKeys.push(ed.author.key);

  const workKey = ed.works && ed.works[0] && ed.works[0].key;
  let subjects = "";
  if (workKey) {
    const work = await fetchJson("https://openlibrary.org" + workKey + ".json");
    if (work) {
      if (work.subjects) subjects = work.subjects.slice(0, 12).join("; ");
      for (const a of work.authors || []) {
        if (a && a.author && a.author.key) authorKeys.push(a.author.key);
      }
    }
  }

  const authors = [];
  for (const key of authorKeys.slice(0, 4)) {
    const person = await fetchJson("https://openlibrary.org" + key + ".json");
    const name = person && (person.name || person.personal_name);
    if (name && authors.indexOf(name) < 0) authors.push(name);
  }

  const coverId = (ed.covers || []).find((id) => id > 0);
  const languageKey = ((ed.languages || [])[0] || {}).key;

  return {
    title: ed.title,
    subtitle: ed.subtitle || "",
    authors: authors.length ? authors.join("; ") : (ed.by_statement || ""),
    publisher: (ed.publishers || []).join("; "),
    published: ed.publish_date || "",
    pub_year: yearOf(ed.publish_date),
    pages: ed.number_of_pages || null,
    language: langName(languageKey && languageKey.split("/").pop()),
    subjects,
    isbn,
    olid: ed.key || "",
    coverUrl: coverId
      ? "https://covers.openlibrary.org/b/id/" + coverId + "-L.jpg"
      : "",
  };
}

/** A work match, which is all the search endpoint gives. Weaker: its dates
    and publishers cover every printing, so it is only a last resort. */
async function fromSearchApi(isbn) {
  const json = await fetchJson(
    OL_SEARCH + "?isbn=" + isbn + "&limit=1&fields=key,title,subtitle,isbn," +
      "author_name,publisher,publish_date,publish_year,number_of_pages_median," +
      "language,subject,cover_i",
  );
  const doc = json && json.docs && json.docs[0];
  if (!doc || !doc.title) return null;
  if (Array.isArray(doc.isbn) && doc.isbn.indexOf(isbn) < 0) return null;

  const dates = doc.publish_date || [];
  const years = doc.publish_year || [];
  const langs = doc.language || [];
  return {
    title: doc.title,
    subtitle: doc.subtitle || "",
    authors: namesOf(doc.author_name, 3),
    publisher: namesOf(doc.publisher, 2),
    published: dates.length === 1 ? dates[0] : (years[0] ? String(years[0]) : ""),
    pub_year: years[0] || null,
    pages: doc.number_of_pages_median || null,
    language: langs.length === 1 ? langName(langs[0]) : "",
    subjects: namesOf(doc.subject, 12),
    isbn,
    olid: doc.key || "",
    coverUrl: doc.cover_i
      ? "https://covers.openlibrary.org/b/id/" + doc.cover_i + "-L.jpg"
      : "",
  };
}

/** Every field the three sources can supply for an ISBN. */
async function lookupIsbn(rawIsbn) {
  const isbn = digitsOnly(rawIsbn);
  if (isbn.length !== 10 && isbn.length !== 13) {
    throw new Error("Enter an ISBN of 10 or 13 digits, then look it up.");
  }

  const found = {};
  const take = (part) => {
    if (!part) return;
    for (const key in part) {
      if (!found[key] && part[key]) found[key] = part[key];
    }
  };

  take(await fromDataApi(isbn));
  if (!found.title) take(await fromEditionApi(isbn));
  if (!found.title) take(await fromSearchApi(isbn));

  if (!found.title) {
    throw new Error("OpenLibrary has no book with ISBN " + isbn + ".");
  }
  if (!found.coverUrl) {
    found.coverUrl = "https://covers.openlibrary.org/b/isbn/" + isbn + "-L.jpg";
  }
  return found;
}

const openLibraryUrl = (row) =>
  row.olid
    ? "https://openlibrary.org" + row.olid
    : row.isbn
      ? "https://openlibrary.org/isbn/" + row.isbn
      : "";

/* ------------------------------------------------------------ small parts */

const stars = (n) => (n ? "★".repeat(n) + "☆".repeat(Math.max(0, 5 - n)) : "");

/** A confirmation dialog. state = { text, ok, variant, action } or null. */
function Confirm({ state, onClose }) {
  return html`
    <${Modal} show=${!!state} onHide=${onClose} centered>
      <${Modal.Body}>${state ? state.text : ""}<//>
      <${Modal.Footer}>
        <${Button} variant="secondary" onClick=${onClose}>Cancel<//>
        <${Button} variant=${(state && state.variant) || "danger"}
          onClick=${async () => {
            const action = state.action;
            onClose();
            await action();
          }}>${(state && state.ok) || "OK"}<//>
      <//>
    <//>`;
}

function CategorySelect({ categories, value, onChange, allLabel, className }) {
  return html`
    <select class=${"form-select " + (className || "")}
      value=${value == null ? "" : String(value)}
      onChange=${(e) => onChange(e.target.value)}>
      <option value="">${allLabel}</option>
      ${categories.map((c) => html`
        <option key=${c.id} value=${String(c.id)}>${c.name}</option>`)}
    </select>`;
}

/** One line of the record view, or nothing when the field is empty. */
const Detail = ({ title, value }) =>
  value == null || value === "" || value === 0 || value === false
    ? null
    : html`
      <tr>
        <th class="text-body-secondary fw-normal pe-3 w-50">${title}</th>
        <td>${value}</td>
      </tr>`;

/* ---------------------------------------------------------- list screen */

function BookList({ db, categories, filter, setFilter, refresh, onOpen, onNew, onCategories }) {
  const [rows, setRows] = useState(null);
  const [error, setError] = useState(null);
  const { q, cat, sort } = filter;

  useEffect(() => {
    let live = true;
    const where = [];
    const args = [];
    const text = q.trim();
    if (text) {
      const p = "%" + text + "%";
      where.push(
        "(b.title like ? or b.authors like ? or b.publisher like ?" +
          " or b.isbn like ? or b.subjects like ? or b.notes like ?)",
      );
      args.push(p, p, p, p, p, p);
    }
    if (cat === "none") where.push("b.category is null");
    else if (cat) {
      where.push("b.category = ?");
      args.push(Number(cat));
    }
    const sql =
      "select b.id, b.title, b.authors, b.published, b.pub_year, b.rating," +
      " b.read_on, b.cover, b.isbn, c.name as cname" +
      " from book b left join category c on c.id = b.category" +
      (where.length ? " where " + where.join(" and ") : "") +
      " order by " + (SORTS[sort] || SORTS.title);
    db.select(sql, args).then(
      (r) => live && setRows(r),
      (e) => live && setError(e.message),
    );
    return () => {
      live = false;
    };
  }, [db, q, cat, sort, refresh]);

  const searching = !!(q.trim() || cat);

  return html`
    <div class="d-flex gap-2 mb-2">
      <${Button} variant="primary" className="flex-fill" onClick=${onNew}>
        ＋ Add book
      <//>
      <${Button} variant="outline-secondary" onClick=${onCategories}>
        Categories
      <//>
    </div>

    <div class="input-group mb-2">
      <span class="input-group-text">🔍</span>
      <input type="search" class="form-control" enterkeyhint="search"
        placeholder="Search title, author, ISBN, notes…"
        value=${q} onInput=${(e) => setFilter({ ...filter, q: e.target.value })} />
    </div>

    <${Row} className="g-2 mb-3">
      <${Col} span=${6}>
        <select class="form-select" value=${cat}
          onChange=${(e) => setFilter({ ...filter, cat: e.target.value })}>
          <option value="">All categories</option>
          ${categories.map((c) => html`
            <option key=${c.id} value=${String(c.id)}>${c.name} (${c.n})</option>`)}
          <option value="none">— Uncategorised —</option>
        </select>
      <//>
      <${Col} span=${6}>
        <select class="form-select" value=${sort}
          onChange=${(e) => setFilter({ ...filter, sort: e.target.value })}>
          <option value="title">Browse: by title</option>
          <option value="author">Browse: by author</option>
          <option value="added">Browse: recently added</option>
          <option value="year">Browse: by year</option>
          <option value="read">Browse: recently read</option>
          <option value="rating">Browse: by rating</option>
        </select>
      <//>
    <//>

    ${error ? html`<${Alert} variant="danger">${error}<//>` : null}

    ${rows === null
      ? html`<div class="text-center py-4"><${Spinner} animation="border" /><//>`
      : rows.length === 0
        ? html`<${Alert} variant="secondary">
            ${searching
              ? "No books match. Try another word or category."
              : "No books yet. Tap “Add book” — you can fill it in from an ISBN."}
          <//>`
        : html`
          <div class="small text-body-secondary mb-1">
            ${rows.length} book${rows.length === 1 ? "" : "s"}${searching ? " found" : ""}
          </div>
          <${ListGroup} className="mb-5">
            ${rows.map((b) => html`
              <${ListGroup.Item} key=${b.id} action
                className="d-flex align-items-center py-2"
                onClick=${() => onOpen(b.id)}>
                ${b.cover
                  ? html`<img src=${file.url(b.cover)} alt=""
                      class="book-thumb rounded me-3" />`
                  : html`<div class="book-thumb-empty rounded me-3">📖</div>`}
                <div class="flex-grow-1 overflow-hidden">
                  <div class="fw-semibold text-truncate">${b.title}</div>
                  <div class="small text-body-secondary text-truncate">
                    ${[b.authors, b.pub_year || b.published].filter(Boolean).join(" · ")}
                  </div>
                  <div class="mt-1 d-flex flex-wrap gap-2 align-items-center">
                    ${b.cname
                      ? html`<${Badge} bg="secondary" className="fw-normal">${b.cname}<//>`
                      : null}
                    ${b.rating
                      ? html`<span class="small text-warning">${stars(b.rating)}</span>`
                      : null}
                    ${b.read_on
                      ? html`<span class="small text-body-secondary">read ${b.read_on}</span>`
                      : null}
                  </div>
                </div>
                <span class="text-body-secondary ms-2">›</span>
              <//>`)}
          <//>`}
  `;
}

/* ---------------------------------------------------------- book screen */

function BookView({ db, id, onEdit, onBack }) {
  const [row, setRow] = useState(null);
  const [error, setError] = useState(null);
  const [confirm, setConfirm] = useState(null);

  useEffect(() => {
    let live = true;
    db.selectOne(
      "select b.*, c.name as cname from book b" +
        " left join category c on c.id = b.category where b.id = ?",
      [id],
    ).then(
      (r) => live && (r ? setRow(r) : setError("That book is no longer in the library.")),
      (e) => live && setError(e.message),
    );
    return () => {
      live = false;
    };
  }, [db, id]);

  if (error) {
    return html`
      <${Alert} variant="danger">${error}<//>
      <${Button} variant="outline-secondary" onClick=${onBack}>‹ Library<//>`;
  }
  if (!row) {
    return html`<div class="text-center py-5"><${Spinner} animation="border" /><//>`;
  }

  const link = openLibraryUrl(row);

  const askDelete = () => setConfirm({
    text: `Delete “${row.title}” from your library? This cannot be undone.`,
    ok: "Delete",
    action: async () => {
      try {
        await deleteCover(row.cover);
        await db.exec("delete from book where id = ?", [row.id]);
        onBack();
      } catch (e) {
        setError(e.message);
      }
    },
  });

  return html`
    <div class="d-flex align-items-center gap-2 mb-3">
      <${Button} variant="outline-secondary" onClick=${onBack}>‹ Library<//>
      <div class="flex-grow-1"></div>
      <${Button} variant="primary" onClick=${onEdit}>✎ Edit<//>
    </div>

    ${row.cover
      ? html`<img src=${file.url(row.cover)} alt="Cover of ${row.title}"
          class="cover-preview d-block mx-auto mb-3" />`
      : html`<div class="cover-empty d-flex align-items-center justify-content-center mb-3">📖</div>`}

    <h5 class="mb-1">${row.title}</h5>
    ${row.subtitle
      ? html`<div class="text-body-secondary mb-1">${row.subtitle}</div>`
      : null}
    ${row.authors ? html`<div class="fst-italic mb-2">${row.authors}</div>` : null}
    ${row.cname
      ? html`<${Badge} bg="secondary" className="fw-normal mb-3">${row.cname}<//>`
      : null}

    <table class="table table-sm mb-3">
      <tbody>
        <${Detail} title="Publisher" value=${row.publisher} />
        <${Detail} title="Published" value=${row.published || row.pub_year} />
        <${Detail} title="Pages" value=${row.pages} />
        <${Detail} title="Language" value=${row.language} />
        <${Detail} title="ISBN" value=${row.isbn} />
        <${Detail} title="Subjects" value=${row.subjects} />
        <${Detail} title="Rating" value=${row.rating ? stars(row.rating) : ""} />
        <${Detail} title="Read on" value=${row.read_on} />
        <tr>
          <th class="text-body-secondary fw-normal pe-3 w-50">Added</th>
          <td>${(row.created || "").slice(0, 10)}</td>
        </tr>
        ${link
          ? html`<tr>
              <th class="text-body-secondary fw-normal pe-3">OpenLibrary</th>
              <td>
                <a href=${link} target="_blank" rel="noopener noreferrer">Open ↗</a>
              </td>
            </tr>`
          : null}
      </tbody>
    </table>

    ${row.notes
      ? html`
        <div class="mb-1 small text-body-secondary">Notes</div>
        <div class="notes-box border rounded p-3 bg-body-tertiary mb-3">${row.notes}</div>`
      : html`<p class="text-body-secondary">No notes yet — Edit to add some.</p>`}

    <div class="mb-5">
      <${Button} variant="outline-danger" size="sm" onClick=${askDelete}>
        Delete book
      <//>
    </div>

    <${Confirm} state=${confirm} onClose=${() => setConfirm(null)} />`;
}

/* --------------------------------------------------------- edit screen */

const BLANK = {
  id: null, title: "", subtitle: "", authors: "", publisher: "", published: "",
  pub_year: null, pages: null, language: "", subjects: "", isbn: "", olid: "",
  category: null, rating: null, read_on: "", notes: "", cover: "",
};

const RATINGS = [
  { value: "", label: "No rating" },
  { value: "1", label: "★ 1" },
  { value: "2", label: "★★ 2" },
  { value: "3", label: "★★★ 3" },
  { value: "4", label: "★★★★ 4" },
  { value: "5", label: "★★★★★ 5" },
];

function BookEditor({ db, id, categories, onClose, onSaved }) {
  const [rec, setRec] = useState(null);
  const [orig, setOrig] = useState(null);
  const [error, setError] = useState(null);
  const [flash, setFlash] = useState(null);
  const [busy, setBusy] = useState(false);
  const [cropping, setCropping] = useState(null);
  const [confirm, setConfirm] = useState(null);

  useEffect(() => {
    let live = true;
    (async () => {
      let r;
      if (id) {
        const row = await db.selectOne("select * from book where id = ?", [id]);
        if (!row) throw new Error("That book is no longer in the library.");
        r = { ...BLANK, ...row };
      } else {
        r = { ...BLANK };
      }
      if (live) {
        setRec(r);
        setOrig(r);
      }
    })().catch((e) => live && setError(e.message));
    return () => {
      live = false;
    };
  }, [db, id]);

  if (!rec) {
    return error
      ? html`
          <${Alert} variant="danger">${error}<//>
          <${Button} variant="outline-secondary" onClick=${onClose}>‹ Library<//>`
      : html`<div class="text-center py-5"><${Spinner} animation="border" /><//>`;
  }

  const dirty = JSON.stringify(rec) !== JSON.stringify(orig);
  const set = (field) => (e) => setRec({ ...rec, [field]: e.target.value });
  const say = (text) => {
    setFlash(text);
    setTimeout(() => setFlash(null), 4000);
  };

  /** The lookup fills every field it can, and brings the cover with it. */
  async function lookup() {
    setError(null);
    setBusy(true);
    try {
      const found = await lookupIsbn(rec.isbn);
      const next = { ...rec };
      for (const k of ["title", "subtitle", "authors", "publisher", "published",
                       "pub_year", "pages", "language", "subjects", "olid"]) {
        if (found[k] !== "" && found[k] != null) next[k] = found[k];
      }
      next.isbn = found.isbn;

      let note = "Filled in from OpenLibrary.";
      if (found.coverUrl) {
        const blob = await fetchImageBlob(found.coverUrl);
        if (blob) {
          next.cover = await storeCover(blob);
          note = "Filled in from OpenLibrary, cover included.";
        } else {
          note = "Filled in from OpenLibrary. No cover was available.";
        }
      }
      setRec(next);
      say(note);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function putPhoto(blob) {
    setError(null);
    setBusy(true);
    try {
      setRec({ ...rec, cover: await storeCover(blob) });
      say("Cover saved.");
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  /** Covers the edit created, but the record never took on. */
  const orphanCovers = () =>
    rec.cover && rec.cover !== (orig && orig.cover) ? [rec.cover] : [];

  async function discard() {
    for (const path of orphanCovers()) await deleteCover(path);
    onClose();
  }

  async function save() {
    setError(null);
    const title = rec.title.trim();
    if (!title) {
      setError("The book needs a title.");
      return;
    }
    const pubYear = yearOf(rec.published) ||
      (rec.pub_year == null || rec.pub_year === "" ? null : Number(rec.pub_year));
    const num = (v) => (v == null || v === "" ? null : Number(v));
    const vals = [
      title,
      rec.subtitle || "", rec.authors || "", rec.publisher || "",
      String(rec.published || ""), pubYear, num(rec.pages),
      rec.language || "", rec.subjects || "", rec.isbn || "", rec.olid || "",
      num(rec.category), num(rec.rating), rec.read_on || "",
      rec.notes || "", rec.cover || "",
    ];
    try {
      const now = new Date().toISOString();
      let bookId = rec.id;
      if (bookId) {
        await db.exec(
          "update book set title = ?, subtitle = ?, authors = ?, publisher = ?," +
            " published = ?, pub_year = ?, pages = ?, language = ?, subjects = ?," +
            " isbn = ?, olid = ?, category = ?, rating = ?, read_on = ?," +
            " notes = ?, cover = ?, updated = ? where id = ?",
          [...vals, now, bookId],
        );
      } else {
        bookId = await db.insert(
          "insert into book (title, subtitle, authors, publisher, published," +
            " pub_year, pages, language, subjects, isbn, olid, category, rating," +
            " read_on, notes, cover, created, updated)" +
            " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
          [...vals, now, now],
        );
      }
      /* The record is stored, so the cover it replaced can go now. */
      if (orig && orig.cover && orig.cover !== rec.cover) {
        await deleteCover(orig.cover);
      }
      onSaved(bookId);
    } catch (e) {
      setError(e.message);
    }
  }

  function back() {
    if (!dirty) return discard();
    setConfirm({
      text: "You have unsaved changes. Discard them?",
      ok: "Discard",
      action: discard,
    });
  }

  const askDelete = () => setConfirm({
    text: `Delete “${rec.title}” from your library? This cannot be undone.`,
    ok: "Delete",
    action: async () => {
      try {
        await deleteCover(rec.cover);
        await db.exec("delete from book where id = ?", [rec.id]);
        onClose();
      } catch (e) {
        setError(e.message);
      }
    },
  });

  const field = (label, name, extra) => html`
    <label class="form-label mt-3">${label}</label>
    <input class="form-control" value=${rec[name] == null ? "" : rec[name]}
      onInput=${set(name)} ...${extra || {}} />`;

  return html`
    <div class="editor-bar d-flex align-items-center gap-2 py-2 mb-3">
      <${Button} variant="outline-secondary" onClick=${back}>‹ Back<//>
      <div class="flex-grow-1 text-truncate fw-semibold">
        ${rec.id ? rec.title || "Book" : "New book"}
      </div>
      ${flash ? html`<${Badge} bg="success">${flash}<//>` : null}
      <${Button} variant="primary" disabled=${!dirty} onClick=${save}>Save<//>
    </div>

    ${error
      ? html`<${Alert} variant="danger" dismissible
          onClose=${() => setError(null)}>${error}<//>`
      : null}

    <div class="border rounded p-3 mb-3 bg-body-tertiary">
      <label class="form-label fw-semibold">Fill from an ISBN</label>
      <div class="input-group">
        <input class="form-control" inputmode="numeric" autocapitalize="off"
          autocorrect="off" spellcheck=${false}
          placeholder="9780140328721"
          value=${rec.isbn} onInput=${set("isbn")}
          onKeyDown=${(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              lookup();
            }
          }} />
        <${Button} variant="outline-primary" disabled=${busy} onClick=${lookup}>
          ${busy ? "Looking…" : "Look up"}
        <//>
      </div>
      <div class="form-text">
        Fetches the title, author, publisher, date, pages, language, subjects
        and the cover photo from openlibrary.org, and fills the fields below.
      </div>
    </div>

    <div class="d-flex align-items-start gap-3">
      ${rec.cover
        ? html`<img src=${file.url(rec.cover)} alt="" class="book-cover-edit rounded" />`
        : html`<div class="book-cover-edit rounded book-thumb-empty d-flex
            align-items-center justify-content-center">📖</div>`}
      <div class="flex-grow-1 d-flex flex-wrap gap-2">
        <${FileButton} accept="image/*" capture="environment" disabled=${busy}
          onFiles=${([f]) => f && setCropping(f)}>📷 Photograph<//>
        <${FileButton} accept="image/*" variant="outline-primary" disabled=${busy}
          onFiles=${([f]) => f && setCropping(f)}>🖼️ Gallery<//>
        ${rec.cover
          ? html`<${Button} variant="outline-danger" disabled=${busy}
              onClick=${() => setRec({ ...rec, cover: "" })}>Remove<//>`
          : null}
      </div>
    </div>

    ${field("Title", "title")}
    ${field("Subtitle", "subtitle")}
    ${field("Author(s)", "authors", { placeholder: "Roald Dahl" })}
    ${field("Publisher", "publisher", { placeholder: "Puffin" })}
    ${field("Published", "published", { placeholder: "1988" })}

    <${Row} className="g-2">
      <${Col} span=${6}>
        ${field("Pages", "pages", { type: "number", inputmode: "numeric", min: "1" })}
      <//>
      <${Col} span=${6}>
        ${field("Language", "language", { placeholder: "English" })}
      <//>
    <//>

    ${field("Subjects", "subjects")}

    <label class="form-label mt-3">Category</label>
    <${CategorySelect} categories=${categories} value=${rec.category}
      allLabel="— No category —"
      onChange=${(v) => setRec({ ...rec, category: v ? Number(v) : null })} />

    <${Row} className="g-2">
      <${Col} span=${6}>
        <label class="form-label mt-3">My rating</label>
        <select class="form-select" value=${rec.rating == null ? "" : String(rec.rating)}
          onChange=${(e) => setRec({
            ...rec, rating: e.target.value === "" ? null : Number(e.target.value),
          })}>
          ${RATINGS.map((r) => html`
            <option key=${r.value} value=${r.value}>${r.label}</option>`)}
        </select>
      <//>
      <${Col} span=${6}>
        <label class="form-label mt-3">Read on</label>
        <input type="date" class="form-control" value=${rec.read_on || ""}
          onInput=${set("read_on")} />
      <//>
    <//>

    <label class="form-label mt-3">Notes</label>
    <textarea class="form-control notes-box" rows="6"
      placeholder="What I thought of it, quotes, who lent it to me…"
      value=${rec.notes} onInput=${set("notes")}></textarea>

    ${rec.id
      ? html`<div class="mt-4 mb-5">
          <${Button} variant="outline-danger" size="sm" onClick=${askDelete}>
            Delete book
          <//>
        </div>`
      : html`<div class="mb-5"></div>`}

    <${ImageCropper} image=${cropping} shape="rect" aspect=${0.667} maxSide=${900}
      title="Crop the cover"
      onCancel=${() => setCropping(null)}
      onDone=${(blob) => {
        setCropping(null);
        putPhoto(blob);
      }} />

    <${Confirm} state=${confirm} onClose=${() => setConfirm(null)} />`;
}

/* ------------------------------------------------------------ categories */

function Categories({ db, categories, reload, onBack }) {
  const [newName, setNewName] = useState("");
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState(null);
  const [confirm, setConfirm] = useState(null);

  async function run(work) {
    setError(null);
    try {
      await work();
      await reload();
    } catch (e) {
      setError(/unique/i.test(e.message)
        ? "A category with that name already exists."
        : e.message);
    }
  }

  const add = () => run(async () => {
    const name = newName.trim();
    if (!name) return;
    await db.insert("insert into category (name) values (?)", [name]);
    setNewName("");
  });

  const rename = () => run(async () => {
    const name = editing.name.trim();
    if (!name) throw new Error("A category needs a name.");
    await db.exec("update category set name = ? where id = ?", [name, editing.id]);
    setEditing(null);
  });

  const askRemove = (c) => setConfirm({
    text: c.n
      ? `Delete “${c.name}”? Its ${c.n} book${c.n === 1 ? "" : "s"} stay in the` +
        " library as uncategorised."
      : `Delete “${c.name}”?`,
    ok: "Delete",
    action: () => run(async () => {
      await db.exec("update book set category = null where category = ?", [c.id]);
      await db.exec("delete from category where id = ?", [c.id]);
    }),
  });

  return html`
    <div class="d-flex align-items-center gap-2 mb-3">
      <${Button} variant="outline-secondary" onClick=${onBack}>‹ Library<//>
      <h5 class="mb-0 flex-grow-1">Categories</h5>
    </div>

    ${error
      ? html`<${Alert} variant="danger" dismissible
          onClose=${() => setError(null)}>${error}<//>`
      : null}

    <div class="input-group mb-3">
      <input class="form-control" placeholder="New category" value=${newName}
        onInput=${(e) => setNewName(e.target.value)}
        onKeyDown=${(e) => e.key === "Enter" && add()} />
      <${Button} variant="primary" disabled=${!newName.trim()} onClick=${add}>Add<//>
    </div>

    <${ListGroup} className="mb-5">
      ${categories.length === 0
        ? html`<${ListGroup.Item} className="text-body-secondary">
            No categories yet.
          <//>`
        : categories.map((c) => html`
          <${ListGroup.Item} key=${c.id}
            className="d-flex align-items-center gap-2">
            ${editing && editing.id === c.id
              ? html`
                <input class="form-control" value=${editing.name}
                  onInput=${(e) => setEditing({ ...editing, name: e.target.value })}
                  onKeyDown=${(e) => e.key === "Enter" && rename()} />
                <${Button} size="sm" variant="primary" onClick=${rename}>Save<//>
                <${Button} size="sm" variant="secondary"
                  onClick=${() => setEditing(null)}>✕<//>`
              : html`
                <div class="flex-grow-1">
                  ${c.name}
                  <span class="text-body-secondary small ms-1">(${c.n})</span>
                </div>
                <${Button} size="sm" variant="outline-secondary"
                  onClick=${() => setEditing({ id: c.id, name: c.name })}>Rename<//>
                <${Button} size="sm" variant="outline-danger"
                  onClick=${() => askRemove(c)}>Delete<//>`}
          <//>`)}
    <//>

    <${Confirm} state=${confirm} onClose=${() => setConfirm(null)} />`;
}

/* ------------------------------------------------------------------ shell */

function App() {
  const [db, setDb] = useState(null);
  const [failure, setFailure] = useState(null);
  const [categories, setCategories] = useState([]);
  const [screen, setScreen] = useState({ name: "list" });
  const [filter, setFilter] = useState({ q: "", cat: "", sort: "title" });
  const [refresh, setRefresh] = useState(0);

  const reloadCategories = async (d = db) => {
    if (d) setCategories(await loadCategories(d));
  };

  useEffect(() => {
    let live = true;
    openDatabase()
      .then(async (opened) => {
        const cats = await loadCategories(opened);
        if (live) {
          setDb(opened);
          setCategories(cats);
        }
      })
      .catch((e) => live && setFailure(e.message));
    return () => {
      live = false;
    };
  }, []);

  const toList = () => {
    reloadCategories().catch((e) => setFailure(e.message));
    setRefresh((n) => n + 1);
    setScreen({ name: "list" });
    window.scrollTo(0, 0);
  };
  const go = (s) => {
    setScreen(s);
    window.scrollTo(0, 0);
  };

  let body;
  if (failure) {
    body = html`<${Alert} variant="danger">${failure}<//>`;
  } else if (!db) {
    body = html`<div class="text-center py-5"><${Spinner} animation="border" /><//>`;
  } else if (screen.name === "categories") {
    body = html`
      <${Categories} db=${db} categories=${categories}
        reload=${() => reloadCategories()} onBack=${toList} />`;
  } else if (screen.name === "book") {
    body = html`
      <${BookView} key=${screen.id} db=${db} id=${screen.id}
        onEdit=${() => go({ name: "editor", id: screen.id })}
        onBack=${toList} />`;
  } else if (screen.name === "editor") {
    body = html`
      <${BookEditor} key=${screen.id || "new"} db=${db} id=${screen.id}
        categories=${categories} onClose=${toList}
        onSaved=${(bookId) => {
          setRefresh((n) => n + 1);
          go({ name: "book", id: bookId });
        }} />`;
  } else {
    body = html`
      <${BookList} db=${db} categories=${categories}
        filter=${filter} setFilter=${setFilter} refresh=${refresh}
        onOpen=${(bookId) => go({ name: "book", id: bookId })}
        onNew=${() => go({ name: "editor", id: null })}
        onCategories=${() => go({ name: "categories" })} />`;
  }

  return html`
    <${Navbar} className="bg-body-tertiary mb-3">
      <${Container} fluid>
        <${Navbar.Brand} href="#" onClick=${(e) => {
          e.preventDefault();
          toList();
        }}>📚 Books<//>
        <${Button} variant="outline-secondary" size="sm" onClick=${closeApp}>
          Exit
        <//>
      <//>
    <//>
    <${Container} fluid style=${{ maxWidth: "820px" }}>
      ${body}
    <//>`;
}

export default function main() {
  render(html`<${App} />`, document.body);
}
