import{html as R,render as Kn,useState as da,useEffect as ua,useCallback as zn,Button as Gn,applyTheme as fa,isDark as ma}from"acelery/ui.js";import{EDITOR_THEMES as Jn}from"acelery/editor.js";import{html as K,useState as Fa}from"acelery/ui.js";import{useState as wa,useEffect as ga}from"acelery/ui.js";function ka(e){let t=String(e??"").replace(/^#\/?/,"").split("/").filter(Boolean).map(Sa);return{section:t[0]??"home",parts:t.slice(1)}}function Sa(e){try{return decodeURIComponent(e)}catch{return e}}function J(e){return"#/"+e.map(t=>encodeURIComponent(t)).join("/")}var be=()=>window.location.hash||"#/",Ue=new Set;function Ke(){for(let e of Ue)e(be())}var ht=!1;function Ca(){ht||(ht=!0,window.addEventListener("popstate",Ke),window.addEventListener("hashchange",Ke))}var te=null;function vt(e){return te=e,()=>{te===e&&(te=null)}}async function h(e,{replace:t=!1}={}){let a=J(e);a!==be()&&(te&&!await te()||(t?window.history.replaceState({from:window.history.state?.from??null},"",a):window.history.pushState({from:be()},"",a),Ke()))}async function yt(e){let t=J(e);if(window.history.state?.from===t){if(te&&!await te())return;window.history.back()}else await h(e,{replace:!0})}function bt(){Ca();let[e,t]=wa(be());return ga(()=>(Ue.add(t),t(be()),()=>Ue.delete(t)),[]),ka(e)}function wt(){new URLSearchParams(window.location.search).get("opt")==="apps"&&window.history.replaceState(null,"",window.location.pathname+J(["apps"]))}var ze=null;function we(e){ze=e}function Ae(e){return ze!==e?!1:(ze=null,!0)}import{html as w,useState as Ie,useEffect as xa,useCallback as Da,useContext as Ea,useRef as St,createContext as Ta,Modal as Pe,Dropdown as Le,Placeholder as gt,Alert as Aa,Toast as La,Button as to}from"acelery/ui.js";var g=({name:e})=>w`<i class=${e} aria-hidden="true"></i>`,Pa="(min-width: 768px)",Ct="(min-width: 992px)";function Ge(e){let t=()=>!!globalThis.matchMedia?.(e).matches,[a,n]=Ie(t);return xa(()=>{let o=globalThis.matchMedia?.(e);if(!o?.addEventListener)return;let i=()=>n(o.matches);return i(),o.addEventListener("change",i),()=>o.removeEventListener("change",i)},[e]),a}function O({icon:e,label:t,onClick:a,disabled:n,primary:o,className:i}){return w`
    <button type="button" aria-label=${t} title=${t}
      class=${`ac-iconbtn${o?" is-primary":""} ${i??""}`}
      disabled=${!!n} onClick=${a}>
      <${g} name=${e} />
    </button>`}function M({icon:e,title:t,children:a,action:n}){return w`
    <div class="ac-empty">
      <div class="ac-empty-icon"><${g} name=${e} /></div>
      <h2>${t}</h2>
      ${a?w`<p>${a}</p>`:null}
      ${n??null}
    </div>`}function L({rows:e=3,grid:t=!1}){let a=(o,i)=>w`
    <${gt} as="div" animation="glow">
      <${gt} xs=${o} size=${i} />
    <//>`,n=Array.from({length:e},(o,i)=>i);return t?w`
      <div class="ac-grid ac-skeleton" aria-busy="true" aria-label="Loading">
        ${n.map(o=>w`
          <div class="ac-card" key=${o}>
            <div class="ac-tile" style=${{background:"var(--ac-surface-2)"}}></div>
            ${a(8)}${a(10,"sm")}
          </div>`)}
      </div>`:w`
    <div class="ac-list ac-skeleton" aria-busy="true" aria-label="Loading">
      ${n.map(o=>w`
        <div class="ac-row" key=${o}>
          <div class="ac-row-icon"></div>
          <div class="ac-row-body">${a(6)}${a(4,"sm")}</div>
        </div>`)}
    </div>`}function j({error:e,onClose:t}){return e?w`
    <${Aa} variant="danger" className="ac-error" dismissible=${!!t}
              onClose=${t}>
      <${g} name="fa-solid fa-triangle-exclamation" />
      <span>${e?.message??String(e)}</span>
    <//>`:null}function W({what:e,action:t}){return w`
    <${M} icon="fa-solid fa-magnifying-glass" title=${`${e} not found`}
      action=${t}>
      It may have been deleted, or the link is out of date.
    <//>`}var xt=Ta(()=>{});function Dt({children:e}){let[t,a]=Ie([]),n=St(0),o=Da(r=>{let s=++n.current;a(c=>[...c.slice(-2),{id:s,text:r}])},[]),i=r=>a(s=>s.filter(c=>c.id!==r));return w`
    <${xt.Provider} value=${o}>
      ${e}
      <div class="ac-toasts">
        ${t.map(r=>w`
          <${La} key=${r.id} className="ac-toast" show autohide delay=${4e3}
                    onClose=${()=>i(r.id)}
                    role="status" aria-live="polite">
            <div class="d-flex align-items-center">
              <div class="toast-body">${r.text}</div>
              <${O} icon="fa-solid fa-xmark" label="Dismiss"
                onClick=${()=>i(r.id)} />
            </div>
          <//>`)}
      </div>
    <//>`}var H=()=>Ea(xt);function ce({show:e,onHide:t,title:a,children:n}){return w`
    <${Pe} show=${e} onHide=${t} centered dialogClassName="ac-sheet">
      ${a?w`<${Pe.Header} closeButton>
            <${Pe.Title} as="h2" className="fs-5">${a}<//>
          <//>`:null}
      ${n}
    <//>`}function ae({label:e="More actions",title:t,actions:a}){let n=Ge(Pa),[o,i]=Ie(!1),r=St(null),s=a.filter(Boolean);return s.length?n?w`
      <${Le} align="end" className="ac-over">
        <${Le.Toggle} as="button" type="button" bsPrefix="ac-iconbtn"
                            aria-label=${e} title=${e}>
          <${g} name="fa-solid fa-ellipsis-vertical" />
        <//>
        <${Le.Menu} popperConfig=${{strategy:"fixed"}}>
          ${s.map(c=>w`
            <${Le.Item} as="button" key=${c.label} disabled=${!!c.disabled}
                              className=${c.danger?"is-danger":""}
                              onClick=${c.onSelect}>
              ${c.icon?w`<${g} name=${c.icon} />`:null}
              <span>${c.label}</span>
            <//>`)}
        <//>
      <//>`:w`
    <span class="ac-over">
      <${O} icon="fa-solid fa-ellipsis-vertical" label=${e}
        onClick=${()=>i(!0)} />
      <${Pe} show=${o} onHide=${()=>i(!1)} centered
                dialogClassName="ac-sheet"
                onExited=${()=>{let c=r.current;r.current=null,c?.()}}>
        ${t?w`<div class="ac-sheet-title">${t}</div>`:null}
        <div class="ac-actions" role="menu" aria-label=${e}>
          ${s.map(c=>w`
            <button key=${c.label} type="button" role="menuitem"
                    class=${`ac-action${c.danger?" is-danger":""}`}
                    disabled=${!!c.disabled}
                    onClick=${()=>{r.current=c.onSelect,i(!1)}}>
              ${c.icon?w`<${g} name=${c.icon} />`:null}
              <span>${c.label}</span>
            </button>`)}
        </div>
      <//>
    </span>`:null}function Fe({label:e,value:t,options:a,onChange:n,role:o="tablist"}){let i=o==="tablist"?"tab":"radio",r=o==="tablist"?"aria-selected":"aria-checked";return w`
    <div class="ac-segmented" role=${o} aria-label=${e}>
      ${a.map(s=>w`
        <button key=${s.value} type="button" role=${i} class="ac-segment"
                ...${{[r]:t===s.value?"true":"false"}}
                disabled=${!!s.disabled} onClick=${()=>n(s.value)}>
          ${s.icon?w`<${g} name=${s.icon} />`:null}
          <span>${s.label}</span>
        </button>`)}
    </div>`}var kt=["#3d6b63","#1f6f8b","#6b4fa0","#a14a2b","#2e7d32","#8a5a00","#9c2f5e","#45617d"];function Ia(e){let t=0;for(let a of e)t=t*31+a.codePointAt(0)>>>0;return kt[t%kt.length]}function Je({name:e,icon:t}){let[a,n]=Ie(!1);return t&&!a?w`
      <div class="ac-tile">
        <img src=${t} alt="" onError=${()=>n(!0)} />
      </div>`:w`
    <div class="ac-tile" style=${{background:Ia(e)}} aria-hidden="true">
      ${([...e][0]??"?").toUpperCase()}
    </div>`}function Me({project:e,verb:t,onOpen:a,actions:n}){return w`
    <div class="ac-card">
      <div class="ac-card-head">
        <${Je} name=${e.name} icon=${e.icon} />
        <${ae} title=${e.name} label=${`Actions for ${e.name}`}
          actions=${n} />
      </div>
      <h3 class="ac-card-title">
        <button type="button" class="ac-stretch"
                aria-label=${`${t} ${e.name}`} onClick=${a}>
          ${e.name}
        </button>
      </h3>
      ${e.description?w`<p class="ac-card-text">${e.description}</p>`:null}
    </div>`}function q({icon:e,title:t,meta:a,onOpen:n,selected:o,actions:i,badge:r}){return w`
    <div class=${`ac-row${n?" is-action":""}${o?" is-selected":""}`}>
      <div class="ac-row-icon" aria-hidden="true"><${g} name=${e} /></div>
      <div class="ac-row-body">
        ${n?w`<button type="button" class="ac-stretch ac-row-title"
                   aria-current=${o?"true":void 0}
                   onClick=${n}>${t}</button>`:w`<div class="ac-row-title">${t}</div>`}
        ${a?w`<div class="ac-row-meta">${a}</div>`:null}
      </div>
      ${r?w`<span class="ac-badge">${r}</span>`:null}
      ${i?w`<${ae} title=${t} label=${`Actions for ${t}`}
                 actions=${i} />`:null}
    </div>`}var Ma=[{key:"home",path:[],label:"Home",icon:"fa-solid fa-house"},{key:"apps",path:["apps"],label:"Apps",icon:"fa-solid fa-table-cells"},{key:"code",path:["code"],label:"Code",icon:"fa-solid fa-code"},{key:"data",path:["data"],label:"Data",icon:"fa-solid fa-database"},{key:"settings",path:["settings"],label:"Settings",icon:"fa-solid fa-gear"}];function Et({section:e}){return Ma.map(t=>K`
      <a key=${t.key} href=${J(t.path)}
         class=${`ac-navitem${t.key==="settings"?" is-settings":""}`}
         aria-current=${e===t.key?"page":void 0}
         onClick=${a=>{a.button!==0||a.metaKey||a.ctrlKey||a.shiftKey||a.altKey||(a.preventDefault(),h(t.path,{replace:!0}))}}>
        <span class="ac-navicon"><${g} name=${t.icon} /></span>
        <span class="ac-navlabel">${t.label}</span>
      </a>`)}function We({section:e,children:t}){return K`
    <div class="ac-frame">
      <nav class="ac-rail" aria-label="Main">
        <div class="ac-brand">
          <span class="ac-brand-mark" aria-hidden="true">
            <${g} name="fa-solid fa-seedling" />
          </span>
          <span class="ac-brand-name">aCelery</span>
        </div>
        <${Et} section=${e} />
      </nav>
      <main class="ac-main">${t}</main>
      <nav class="ac-bottomnav" aria-label="Main">
        <${Et} section=${e} />
      </nav>
    </div>`}function D({title:e,subtitle:t,back:a,actions:n,subbar:o,fab:i,fill:r,children:s}){let[c,d]=Fa(!1);return K`
    <section class="ac-screen" aria-labelledby="ac-screen-title">
      <header class=${`ac-appbar${a?"":" no-back"}${c?" is-scrolled":""}${o?" has-subbar":""}`}>
        ${a?K`<${O} icon="fa-solid fa-arrow-left" label="Back"
                   onClick=${()=>yt(a)} />`:null}
        <div class="ac-appbar-titles">
          <h1 class="ac-appbar-title" id="ac-screen-title">${e}</h1>
          ${t?K`<div class="ac-appbar-subtitle">${t}</div>`:null}
        </div>
        <div class="ac-appbar-actions">${n??null}</div>
      </header>
      ${o?K`<div class="ac-subbar">${o}</div>`:null}
      ${r?K`<div class="ac-content is-fill">${s}</div>`:K`
            <div class=${`ac-content${i?" has-fab":""}`}
                 onScroll=${l=>d(l.currentTarget.scrollTop>0)}>
              <div class="ac-content-inner">${s}</div>
            </div>`}
      ${i?K`
            <button type="button" class="ac-fab" aria-label=${i.label}
                    onClick=${i.onClick}>
              <${g} name=${i.icon} />
              <span class="ac-fab-label" aria-hidden="true">${i.label}</span>
            </button>`:null}
    </section>`}import*as I from"acelery/file.js";import{openDB as At}from"acelery/sql.js";var Tt="/system/scaffold/",ja=/\{\{name\}\}/g;function Ba(e,t){let a=new RegExp(e.namePattern),{messages:n}=e;return{entry:e.entry,nameProblem(o){let i=(o??"").trim();return i?a.test(i)?null:n.nameInvalid:n.nameRequired},descriptionProblem(o){return(o??"").length<=e.descriptionMax?null:n.descriptionTooLong},projectName(o){let i=o.trim();return i.charAt(0).toUpperCase()+i.slice(1)},files(o,i){let r={"acelery_app.json":JSON.stringify({name:o,description:i??"",entry:e.entry})};for(let s of Object.keys(e.templates))r[s]=t[s].replace(ja,o);return r}}}var Qe=null;function je(){return Qe??=(async()=>{let e=async n=>{let o=await fetch(Tt+n);if(!o.ok)throw new Error(`${Tt}${n}: ${o.status}`);return o.text()},t=JSON.parse(await e("scaffold.json")),a={};for(let[n,o]of Object.entries(t.templates))a[n]=await e(o);return Ba(t,a)})().catch(e=>{throw Qe=null,e}),Qe}async function Lt(){let e=await At("acelery.db");try{await e.exec("create table if not exists config (cfg_key text unique, cfg_value text)");let t=await e.select("select cfg_key, cfg_value from config");return Object.fromEntries(t.map(a=>[a.cfg_key,a.cfg_value]))}finally{await e.close()}}async function Pt(e){let t=await At("acelery.db");try{await t.exec("create table if not exists config (cfg_key text unique, cfg_value text)");for(let[a,n]of Object.entries(e))await t.exec("insert into config (cfg_key, cfg_value) values (?, ?) on conflict(cfg_key) do update set cfg_value = excluded.cfg_value",[a,n??""])}finally{await t.close()}}var Ve=null;function It(){return Ve??=I.externalStoragePath().catch(e=>{throw Ve=null,e}),Ve}async function z(){return await It()+"/aCelery/www/user/"}async function Ra(){return await It()+"/aCelery/"}function Oa(e,t){return typeof t!="string"||!/^[\w.-]+(\/[\w.-]+)*$/.test(t)||t.split("/").includes("..")?null:`/user/${encodeURIComponent(e)}/${t}`}async function Ye(e,t){t??=await z();try{let a=await I.open("acelery_app.json",t+e),n=await a.read();await a.close();let o=n?JSON.parse(n):{};return{description:typeof o.description=="string"?o.description:"",entry:typeof o.entry=="string"&&o.entry?o.entry:"main.js",icon:Oa(e,o.icon)}}catch{return{description:"",entry:"main.js",icon:null}}}async function de(){let e=await z(),t=await I.listFiles("user",e.replace(/user\/$/,"")),a=[];for(let n of t)n.directory&&a.push({name:n.fname,...await Ye(n.fname,e)});return a.sort((n,o)=>n.name.localeCompare(o.name))}async function Ft(e){let t=await z();return(await I.listFiles("user",t.replace(/user\/$/,""))).some(n=>n.directory&&n.fname===e)}async function Be(e){return(await I.listFiles(e,await z())).filter(a=>!a.directory).map(a=>({name:a.fname,length:a.length,modified:a.lastmodified})).sort((a,n)=>a.name.localeCompare(n.name))}async function Mt(e,t){let a=await I.open(t,await z()+e);try{return await a.read()}finally{await a.close()}}async function ge(e,t,a){let n=await I.open(t,await z()+e);try{await n.write(a)}finally{await n.close()}}async function jt(e,t){await(await I.open(t,await z()+e)).delete()}async function ue(e){await(await I.open(e,await z())).delete()}async function Bt({name:e,description:t}){let a=await je(),n=a.projectName(e),o=await z();await I.mkdir(n,o);for(let[i,r]of Object.entries(a.files(n,t)))await ge(n,i,r);return n}async function ke(){return(await I.listFiles("db",await Ra())).filter(t=>!t.directory&&!t.fname.includes("journal")).map(t=>({name:t.fname,length:t.length,modified:t.lastmodified})).sort((t,a)=>t.name.localeCompare(a.name))}async function Rt(e){return(await ke()).some(t=>t.name===e)}function Re(e){if(!/^[A-Za-z_][A-Za-z0-9_]*$/.test(e))throw new Error(`"${e}" is not a usable table name`);return e}function Q(){return!!globalThis.ACeleryHost}function Ot(){return Q()&&/\bAndroid\b/.test(globalThis.navigator?.userAgent??"")}function G(e){globalThis.ACeleryHost?.postMessage(JSON.stringify(e))}function fe(e){return typeof e!="number"||!Number.isFinite(e)?"":e<1024?`${e} B`:e<1024*1024?`${(e/1024).toFixed(e<10240?1:0)} KB`:`${(e/1024/1024).toFixed(1)} MB`}function Ht(e){if(typeof e!="number"||!e)return"";let t=new Date(e);return t.toDateString()===new Date().toDateString()?t.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}):t.toLocaleDateString([],{day:"numeric",month:"short",year:"numeric"})}import{html as V,useState as qt,useEffect as Ha,Button as Se}from"acelery/ui.js";import{runApp as _t}from"acelery/export.js";function qa(e=new Date){let t=e.getHours();return t<5?"Working late":t<12?"Good morning":t<18?"Good afternoon":"Good evening"}var Nt=e=>t=>{t.button!==0||t.metaKey||t.ctrlKey||t.shiftKey||t.altKey||(t.preventDefault(),h(e))};function Ut({settings:e,updateSettings:t}){let[a,n]=qt(null),[o,i]=qt(null);Ha(()=>{let v=!0;return(async()=>{try{let[$,m]=await Promise.all([de(),ke()]);if(!v)return;n({projects:$,databases:m});let S={},T=e["recent.project"];T&&!$.some(C=>C.name===T)&&(S["recent.project"]="",S["recent.file"]="");let b=e["recent.db"];b&&!m.some(C=>C.name===b)&&(S["recent.db"]=""),Object.keys(S).length&&t(S)}catch($){if(!v)return;i($),n({projects:[],databases:[]})}})(),()=>{v=!1}},[]);let r=a?.projects.find(v=>v.name===e["recent.project"]),s=r?e["recent.file"]:"",c=a?.databases.find(v=>v.name===e["recent.db"]),d=a?.projects.find(v=>v.name==="Example"),l=()=>{we("new-project"),h(["code"])},u=()=>{we("new-db"),h(["data"])},y;a?r||c?y=V`
      <div class="ac-continue">
        ${r?V`
              <div class="ac-continue-card">
                <${Je} name=${r.name} icon=${r.icon} />
                <div class="ac-row-body">
                  <div class="ac-row-title">${r.name}</div>
                  <div class="ac-row-meta">${s||r.description||"Project"}</div>
                </div>
                <div class="ac-button-row">
                  <${Se} variant="outline-primary"
                    onClick=${()=>h(s?["code",r.name,s]:["code",r.name])}>
                    Open
                  <//>
                  <${Se} variant="primary"
                    onClick=${()=>_t(r.name,r.name,!0)}>
                    <${g} name="fa-solid fa-play" /> Run
                  <//>
                </div>
              </div>`:null}
        ${c?V`
              <div class="ac-continue-card">
                <div class="ac-row-icon" aria-hidden="true">
                  <${g} name="fa-solid fa-database" />
                </div>
                <div class="ac-row-body">
                  <div class="ac-row-title">${c.name}</div>
                  <div class="ac-row-meta">Database · ${fe(c.length)}</div>
                </div>
                <div class="ac-button-row">
                  <${Se} variant="outline-primary" onClick=${()=>h(["data",c.name])}>
                    Open
                  <//>
                </div>
              </div>`:null}
      </div>`:y=V`
      <div class="ac-welcome">
        <h2>Welcome to aCelery</h2>
        <p>
          An aCelery app is a few JavaScript files you write on this device and
          run straight away. Try the example, or start your own.
        </p>
        <div class="ac-button-row">
          ${d?V`<${Se} variant="primary"
                     onClick=${()=>_t(d.name,d.name,!1)}>
                <${g} name="fa-solid fa-play" /> Run the Example app
              <//>`:null}
          <${Se} variant=${d?"outline-primary":"primary"} onClick=${l}>
            Create your first app
          <//>
        </div>
      </div>`:y=V`<${L} rows=${2} />`;let k=v=>v?String(v.length):"\u2013";return V`
    <${D} title=${V`
      <span class="ac-brand-inline">
        <span class="ac-brand-mark" aria-hidden="true"><${g} name="fa-solid fa-seedling" /></span>
        aCelery
      </span>`}>
      <${j} error=${o} onClose=${()=>i(null)} />
      <div class="ac-home">
        <div>
          <div class="ac-hero">
            <h2>${qa()}</h2>
            <p>Build and run your own JavaScript apps.</p>
          </div>
          <section class="ac-section" aria-label=${r||c?"Continue":"Get started"}>
            <h2 class="ac-section-title">${r||c?"Continue":"Get started"}</h2>
            ${y}
          </section>
        </div>
        <div>
          <section class="ac-section">
            <h2 class="ac-section-title">Create</h2>
            <div class="ac-quick">
              <button type="button" class="ac-quick-btn" onClick=${l}>
                <span class="ac-quick-icon"><${g} name="fa-solid fa-code" /></span>
                New app
              </button>
              <button type="button" class="ac-quick-btn" onClick=${u}>
                <span class="ac-quick-icon"><${g} name="fa-solid fa-database" /></span>
                New database
              </button>
            </div>
          </section>
          <section class="ac-section">
            <h2 class="ac-section-title">On this device</h2>
            <div class="ac-stats">
              <a class="ac-stat" href=${J(["apps"])} onClick=${Nt(["apps"])}>
                <span class="ac-stat-value">${k(a?.projects)}</span>
                <span class="ac-stat-label">${a?.projects.length===1?"app":"apps"}</span>
              </a>
              <a class="ac-stat" href=${J(["data"])} onClick=${Nt(["data"])}>
                <span class="ac-stat-value">${k(a?.databases)}</span>
                <span class="ac-stat-label">
                  ${a?.databases.length===1?"database":"databases"}
                </span>
              </a>
            </div>
          </section>
        </div>
      </div>
    <//>`}import{html as N,useState as Ze,useEffect as Ka,useCallback as za,Button as Ga}from"acelery/ui.js";import{runApp as Ja,exportProject as Wa}from"acelery/export.js";import{html as _a,useState as Na,useCallback as Ua,Modal as Ce,Button as Kt}from"acelery/ui.js";function _(){let[e,t]=Na(null),a=Ua((i,{title:r="aCelery",danger:s=!1,confirmLabel:c="OK",cancelLabel:d="Cancel",dismissValue:l=!1}={})=>new Promise(u=>t({message:i,title:r,danger:s,confirmLabel:c,cancelLabel:d,dismissValue:l,resolve:u})),[]),n=i=>{e?.resolve(i),t(null)},o=e?_a`
        <${Ce} show onHide=${()=>n(e.dismissValue)} centered>
          <${Ce.Header} closeButton>
            <${Ce.Title} as="h2" className="fs-5">${e.title}<//>
          <//>
          <${Ce.Body}>${e.message}<//>
          <${Ce.Footer}>
            <${Kt} variant="outline-secondary" onClick=${()=>n(!1)}>
              ${e.cancelLabel}
            <//>
            <${Kt} variant=${e.danger?"danger":"primary"}
                       onClick=${()=>n(!0)}>
              ${e.confirmLabel}
            <//>
          <//>
        <//>`:null;return{confirm:a,dialog:o}}var Xe=6;function et({value:e,onChange:t,label:a}){return N`
    <div class="ac-search" role="search">
      <${g} name="fa-solid fa-magnifying-glass" />
      <input type="search" class="form-control" aria-label=${a}
             placeholder=${a} value=${e}
             onInput=${n=>t(n.currentTarget.value)} />
    </div>`}function tt(e,t){let a=t.trim().toLowerCase();return!a||e.name.toLowerCase().includes(a)||e.description.toLowerCase().includes(a)}async function xe(e,t){return e(`${t} and all of its files will be deleted. This cannot be undone.`,{title:`Delete ${t}?`,danger:!0,confirmLabel:"Delete"})}function zt({settings:e,updateSettings:t}){let[a,n]=Ze(null),[o,i]=Ze(null),[r,s]=Ze(""),c=H(),{confirm:d,dialog:l}=_(),u=za(async()=>{try{n(await de())}catch(v){i(v),n([])}},[]);Ka(()=>{u()},[u]);async function y(v){if(await xe(d,v.name))try{await ue(v.name),e["recent.project"]===v.name&&t({"recent.project":"","recent.file":""}),c(`Deleted ${v.name}`),await u()}catch($){i($)}}let k;if(a===null)k=N`<${L} rows=${4} grid />`;else if(!a.length)k=N`
      <${M} icon="fa-solid fa-table-cells" title="No apps yet"
        action=${N`
          <${Ga} variant="primary"
            onClick=${()=>{we("new-project"),h(["code"])}}>
            Create an app
          <//>`}>
        An app is a folder of JavaScript you write in Code.
      <//>`;else{let v=a.filter($=>tt($,r));k=N`
      ${a.length>Xe?N`<div class="ac-toolbar">
            <${et} label="Search apps" value=${r} onChange=${s} />
          </div>`:null}
      ${v.length?N`
            <div class="ac-grid">
              ${v.map($=>N`
                <${Me} key=${$.name} project=${$} verb="Run"
                  onOpen=${()=>Ja($.name,$.name,!1)}
                  actions=${[{label:"Edit in Code",icon:"fa-solid fa-pen-to-square",onSelect:()=>h(["code",$.name])},Ot()&&{label:"Add to home screen",icon:"fa-solid fa-mobile-screen",onSelect:()=>G({action:"addShortcut",app:$.name})},{label:"Export",icon:"fa-solid fa-file-export",onSelect:()=>Wa($.name)},{label:"Delete",icon:"fa-solid fa-trash",danger:!0,onSelect:()=>y($)}]} />`)}
            </div>`:N`<p class="text-body-secondary px-1">Nothing matches “${r}”.</p>`}`}return N`
    <${D} title="Apps">
      <${j} error=${o} onClose=${()=>i(null)} />
      ${k}
    <//>
    ${l}`}import{html as B,useState as De,useEffect as Gt,useCallback as Qa,Button as at,Modal as Jt,Form as Va,Input as Wt,notEmpty as Ya}from"acelery/ui.js";import{runApp as Za,exportProject as Xa,importProject as en}from"acelery/export.js";function tn({show:e,scaffold:t,existing:a,onClose:n,onCreate:o}){let i=r=>{let s=(r??"").trim().toLowerCase();return a.some(c=>c.name.toLowerCase()===s)?"A project with that name already exists":!0};return B`
    <${ce} show=${e} onHide=${n} title="New project">
      <${Va} initial=${{name:"",description:""}} onSubmit=${o}>
        <${Jt.Body}>
          <${Wt} label="Name" name="name"
            placeholder="Letters and numbers, 16 max"
            autocapitalize="off" autocomplete="off" spellcheck=${!1}
            validate=${[Ya("A name is required"),r=>t.nameProblem(r)??!0,i]} />
          <${Wt} label="Description" name="description" as="textarea"
            placeholder="What it does, in a sentence (optional)"
            validate=${[r=>t.descriptionProblem(r)??!0]} />
        <//>
        <${Jt.Footer}>
          <${at} variant="outline-secondary" type="button" onClick=${n}>
            Cancel
          <//>
          <${at} variant="primary" type="submit">Create project<//>
        <//>
      <//>
    <//>`}function Qt({settings:e,updateSettings:t}){let[a,n]=De(null),[o,i]=De(null),[r,s]=De(null),[c,d]=De(""),[l,u]=De(()=>Ae("new-project")),y=H(),{confirm:k,dialog:v}=_(),$=Qa(async()=>{try{n(await de())}catch(b){s(b),n([])}},[]);Gt(()=>{$()},[$]),Gt(()=>{je().then(i,s)},[]);async function m(b){u(!1);try{let C=await Bt(b);y(`Created ${C}`),h(["code",C,o.entry])}catch(C){s(C)}}async function S(b){if(await xe(k,b.name))try{await ue(b.name),e["recent.project"]===b.name&&t({"recent.project":"","recent.file":""}),y(`Deleted ${b.name}`),await $()}catch(C){s(C)}}let T;if(a===null)T=B`<${L} rows=${4} grid />`;else if(!a.length)T=B`
      <${M} icon="fa-solid fa-folder" title="No projects yet"
        action=${B`
          <${at} variant="primary" onClick=${()=>u(!0)}>
            New project
          <//>`}>
        A project is a folder holding an app's JavaScript, CSS and manifest.
      <//>`;else{let b=a.filter(C=>tt(C,c));T=B`
      ${a.length>Xe?B`<div class="ac-toolbar">
            <${et} label="Search projects" value=${c} onChange=${d} />
          </div>`:null}
      ${b.length?B`
            <div class="ac-grid">
              ${b.map(C=>B`
                <${Me} key=${C.name} project=${C} verb="Open"
                  onOpen=${()=>h(["code",C.name])}
                  actions=${[{label:"Run",icon:"fa-solid fa-play",onSelect:()=>Za(C.name,C.name,!0)},{label:"Export",icon:"fa-solid fa-file-export",onSelect:()=>Xa(C.name)},{label:"Delete",icon:"fa-solid fa-trash",danger:!0,onSelect:()=>S(C)}]} />`)}
            </div>`:B`<p class="text-body-secondary px-1">Nothing matches “${c}”.</p>`}`}return B`
    <${D} title="Code"
      actions=${Q()?B`<${O} icon="fa-solid fa-file-import" label="Import project"
                 onClick=${en} />`:null}
      fab=${{icon:"fa-solid fa-plus",label:"New project",onClick:()=>u(!0)}}>
      <${j} error=${r} onClose=${()=>s(null)} />
      ${T}
    <//>
    ${o?B`<${tn} show=${l} scaffold=${o}
          existing=${a??[]}
          onClose=${()=>u(!1)} onCreate=${m} />`:null}
    ${v}`}import{html as x,useState as Y,useEffect as ne,useRef as $e,useCallback as Vt,Button as me,Modal as Yt,Form as an,Input as nn,Select as on,notEmpty as rn}from"acelery/ui.js";import{runApp as sn,exportProject as ln}from"acelery/export.js";var Oe=e=>e.includes(".")?e.split(".").pop().toLowerCase():"",nt={js:"JavaScript",mjs:"JavaScript",json:"JSON",css:"CSS",html:"HTML",htm:"HTML",xml:"XML",svg:"SVG",md:"Markdown",txt:"Text"},Zt=new Set(["png","jpg","jpeg","gif","webp","bmp","ico"]),cn=new Set(["zip","woff","woff2","ttf","otf","mp3","mp4","pdf","db"]);function dn(e){let t=Oe(e);return Zt.has(t)?"fa-solid fa-file-image":["md","txt"].includes(t)?"fa-solid fa-file-lines":nt[t]?"fa-solid fa-file-code":"fa-solid fa-file"}function un(e){let t=Oe(e);return Zt.has(t)?"image":cn.has(t)?"binary":"text"}function fn({show:e,project:t,existing:a,onClose:n,onCreate:o}){return x`
    <${ce} show=${e} onHide=${n} title=${`New file in ${t}`}>
      <${an} initial=${{name:"",type:".js"}} onSubmit=${o}>
        <${Yt.Body}>
          <${nn} label="Name" name="name" placeholder="File name without extension"
            autocapitalize="off" autocomplete="off" spellcheck=${!1}
            validate=${[rn("A name is required"),i=>/^[\w.-]+$/.test((i??"").trim())?!0:"Letters, numbers, dot, dash and underscore only"]} />
          <${on} label="Type" name="type" options=${[{label:"JavaScript",value:".js"},{label:"CSS",value:".css"}]} />
        <//>
        <${Yt.Footer}>
          <${me} variant="outline-secondary" type="button" onClick=${n}>
            Cancel
          <//>
          <${me} variant="primary" type="submit"
            onClick=${i=>{let r=i.currentTarget.form,s=`${r.elements.name.value.trim()}${r.elements.type.value}`;a.some(c=>c.name===s)&&(i.preventDefault(),o({duplicate:s}))}}>
            Create file
          <//>
        <//>
      <//>
    <//>`}function Xt({project:e,fileName:t,editorTheme:a,settings:n,updateSettings:o}){let i=Ge(Ct),r=H(),{confirm:s,dialog:c}=_(),[d,l]=Y("loading"),[u,y]=Y([]),[k,v]=Y(null),[$,m]=Y(null),[S,T]=Y(!1),[b,C]=Y(null),[re,he]=Y(!1),[Ee,ve]=Y(!1),se=$e(null),A=$e(null),P=$e(!1),Z=$e(null);Z.current=b;let st=$e(a);st.current=a;let le=f=>{P.current=f,he(f)},lt=Vt(async()=>{y(await Be(e))},[e]);ne(()=>{let f=!0;return(async()=>{try{if(!await Ft(e)){f&&l("missing");return}let[E,F]=await Promise.all([Be(e),Ye(e)]);if(!f)return;y(E),v(F),l("ready")}catch(E){if(!f)return;m(E),l("ready")}})(),()=>{f=!1}},[e]),ne(()=>{d==="ready"&&!t&&n["recent.project"]!==e&&o({"recent.project":e,"recent.file":""})},[d,e,t]),ne(()=>{if(C(null),d!=="ready"||!t)return;let f=!0;return(async()=>{try{let E=await Be(e);if(!f)return;if(!E.some(ba=>ba.name===t)){C({name:t,kind:"missing"});return}let F=un(t),Ne=F==="text"?await Mt(e,t):null;if(!f)return;C({name:t,kind:F,text:Ne}),o({"recent.project":e,"recent.file":t})}catch(E){f&&m(E)}})(),()=>{f=!1}},[e,t,d]);let ye=Vt(async()=>{let f=A.current,E=Z.current;if(!f||E?.kind!=="text")return!0;let F=f.getValue();ve(!0);try{return await ge(e,E.name,F),A.current===f&&f.getValue()===F&&le(!1),!0}catch(Ne){return m(Ne),!1}finally{ve(!1)}},[e]),Te=$e(ye);Te.current=ye,ne(()=>{if(b?.kind!=="text"||!se.current)return;let f=b.name,E=globalThis.aceleryEditor.createEditor(se.current,{value:b.text,filename:f,theme:st.current,onChange:()=>{P.current||le(!0)},onSave:()=>Te.current()});return A.current=E,le(!1),()=>{P.current&&(ge(e,f,E.getValue()).catch(F=>console.error(`aCelery: could not save ${f}`,F)),P.current=!1),E.destroy(),A.current===E&&(A.current=null)}},[b]),ne(()=>{A.current?.setTheme(a)},[a]),ne(()=>(globalThis.forceSaveFile=()=>{P.current&&Te.current()},()=>{delete globalThis.forceSaveFile}),[]),ne(()=>vt(async()=>{if(!P.current)return!0;let f=await s(`Save your changes to ${Z.current?.name??"this file"} before leaving?`,{title:"Unsaved changes",confirmLabel:"Save",cancelLabel:"Discard",dismissValue:null});return f===null?!1:f?Te.current():(le(!1),!0)}),[s]);async function pa(){P.current&&!await ye()||sn(e,e,!0)}async function ha(){P.current&&!await ye()||ln(e)}async function va(f){if(f.duplicate){m(new Error(`${f.duplicate} already exists in ${e}`)),T(!1);return}T(!1);let E=f.name.trim()+f.type;try{await ge(e,E,""),await lt(),h(["code",e,E],{replace:i&&!!t})}catch(F){m(F)}}async function ct(f){if(await s(`${f} will be deleted from ${e}. This cannot be undone.`,{title:`Delete ${f}?`,danger:!0,confirmLabel:"Delete"}))try{f===t&&le(!1),await jt(e,f),await lt(),r(`Deleted ${f}`),f===t&&h(["code",e],{replace:!0})}catch(F){m(F)}}async function ya(){if(await xe(s,e))try{le(!1),await ue(e),n["recent.project"]===e&&o({"recent.project":"","recent.file":""}),r(`Deleted ${e}`),h(["code"],{replace:!0})}catch(f){m(f)}}let dt=f=>h(["code",e,f],{replace:i&&!!t});if(d==="missing")return x`
      <${D} title=${e} back=${["code"]}>
        <${W} what="Project" action=${x`
          <${me} variant="primary" onClick=${()=>h(["code"],{replace:!0})}>
            All projects
          <//>`} />
      <//>`;if(d==="loading")return x`
      <${D} title=${e} back=${["code"]}>
        <${L} rows=${4} />
      <//>`;let X=!!t,ut=x`<${j} error=${$} onClose=${()=>m(null)} />`,ft=u.length?x`
        <div class="ac-list">
          ${u.map(f=>x`
            <${q} key=${f.name} icon=${dn(f.name)} title=${f.name}
              meta=${`${nt[Oe(f.name)]??"File"} \xB7 ${fe(f.length)}`}
              badge=${f.name===k?.entry?"entry":null}
              selected=${f.name===t}
              onOpen=${()=>dt(f.name)}
              actions=${[{label:"Delete",icon:"fa-solid fa-trash",danger:!0,onSelect:()=>ct(f.name)}]} />`)}
        </div>`:x`
        <${M} icon="fa-solid fa-file-code" title="No files yet"
          action=${x`<${me} variant="primary" onClick=${()=>T(!0)}>
            New file
          <//>`}>
          Add a JavaScript file for the app to run.
        <//>`,ee;if(X)b?b.kind==="missing"?ee=x`
      <${W} what="File" action=${x`
        <${me} variant="primary"
          onClick=${()=>h(["code",e],{replace:!0})}>
          Back to ${e}
        <//>`} />`:b.kind==="image"?ee=x`
      <div class="ac-preview">
        <img alt=${b.name}
          src=${`/user/${encodeURIComponent(e)}/${encodeURIComponent(b.name)}`} />
      </div>`:b.kind==="binary"?ee=x`
      <${M} icon="fa-solid fa-file" title="Not a text file">
        ${b.name} can't be edited here.
      <//>`:ee=x`
      <div class="ac-editor-host"><div class="ac-editor-mount" ref=${se}></div></div>
      <div class="ac-status">
        <span>${nt[Oe(b.name)]??"Text"}</span>
        <span role="status">${Ee?"Saving\u2026":re?"Unsaved changes":"Saved"}</span>
      </div>`:ee=x`<div class="ac-empty" aria-busy="true"><p>Opening ${t}…</p></div>`;else{let f=u.find(E=>E.name===k?.entry);ee=x`
      <${M} icon="fa-solid fa-file-code" title="Pick a file"
        action=${f?x`<${me} variant="outline-primary" onClick=${()=>dt(f.name)}>
              Open ${f.name}
            <//>`:null}>
        Choose a file from the list to edit it.
      <//>`}let $t=X?x`${t}${re?x`<span class="ac-dirty" role="img" aria-label="unsaved changes"></span>`:null}`:e,mt=x`
    ${b?.kind==="text"?x`<${O} icon="fa-solid fa-floppy-disk" label="Save"
               disabled=${!re||Ee} onClick=${ye} />`:null}
    <${O} icon="fa-solid fa-play" label=${`Run ${e}`} primary onClick=${pa} />
    <${ae} title=${X?t:e} actions=${[{label:"New file",icon:"fa-solid fa-plus",onSelect:()=>T(!0)},{label:"Export project",icon:"fa-solid fa-file-export",onSelect:ha},X&&{label:`Delete ${t}`,icon:"fa-solid fa-trash",danger:!0,onSelect:()=>ct(t)},{label:"Delete project",icon:"fa-solid fa-trash",danger:!0,onSelect:ya}]} />`,pt=x`
    <${fn} show=${S} project=${e} existing=${u}
      onClose=${()=>T(!1)} onCreate=${va} />
    ${c}`;return!i&&!X?x`
      <${D} title=${$t} subtitle=${k?.description||null} back=${["code"]}
        actions=${mt}
        fab=${{icon:"fa-solid fa-plus",label:"New file",onClick:()=>T(!0)}}>
        ${ut}
        <h2 class="ac-section-title">Files</h2>
        ${ft}
      <//>
      ${pt}`:x`
    <${D} title=${$t} subtitle=${X?e:k?.description||null}
      back=${X?["code",e]:["code"]} actions=${mt} fill>
      <div class="ac-split">
        ${i?x`
              <aside class="ac-sidebar" aria-label="Files">
                <div class="ac-sidebar-head">
                  <h2 class="ac-section-title">Files</h2>
                  <${O} icon="fa-solid fa-plus" label="New file"
                    onClick=${()=>T(!0)} />
                </div>
                ${ft}
              </aside>`:null}
        <div class="ac-pane">
          ${ut}
          ${ee}
        </div>
      </div>
    <//>
    ${pt}`}import{html as oe,useState as ot,useEffect as $n,useCallback as mn,Button as it,Modal as ea,Form as pn,Input as hn,notEmpty as vn}from"acelery/ui.js";import{openDB as yn,deleteDB as bn}from"acelery/sql.js";function wn({show:e,existing:t,onClose:a,onCreate:n}){return oe`
    <${ce} show=${e} onHide=${a} title="New database">
      <${pn} initial=${{name:""}} onSubmit=${n}>
        <${ea.Body}>
          <${hn} label="Name" name="name" placeholder="Database name without extension"
            autocapitalize="off" autocomplete="off" spellcheck=${!1}
            help="Saved as a SQLite file ending in .db."
            validate=${[vn("A name is required"),o=>/^[\w-]+$/.test((o??"").trim())?!0:"Letters, numbers, dash and underscore only",o=>t.some(i=>i.name===`${(o??"").trim()}.db`)?"A database with that name already exists":!0]} />
        <//>
        <${ea.Footer}>
          <${it} variant="outline-secondary" type="button" onClick=${a}>
            Cancel
          <//>
          <${it} variant="primary" type="submit">Create database<//>
        <//>
      <//>
    <//>`}function ta({settings:e,updateSettings:t}){let[a,n]=ot(null),[o,i]=ot(null),[r,s]=ot(()=>Ae("new-db")),c=H(),{confirm:d,dialog:l}=_(),u=mn(async()=>{try{n(await ke())}catch($){i($),n([])}},[]);$n(()=>{u()},[u]);async function y({name:$}){s(!1);let m=`${$.trim()}.db`;try{await(await yn(m)).close(),c(`Created ${m}`),h(["data",m])}catch(S){i(S)}}async function k($){if(await d(`${$} and every table in it will be deleted. This cannot be undone.`,{title:`Delete ${$}?`,danger:!0,confirmLabel:"Delete"}))try{await bn($),e["recent.db"]===$&&t({"recent.db":""}),c(`Deleted ${$}`),await u()}catch(S){i(S)}}let v;return a===null?v=oe`<${L} rows=${3} />`:a.length?v=oe`
      <div class="ac-list">
        ${a.map($=>oe`
          <${q} key=${$.name} icon="fa-solid fa-database" title=${$.name}
            meta=${[fe($.length),Ht($.modified)].filter(Boolean).join(" \xB7 ")}
            badge=${$.name==="acelery.db"?"settings":null}
            onOpen=${()=>h(["data",$.name])}
            actions=${[{label:"Delete",icon:"fa-solid fa-trash",danger:!0,onSelect:()=>k($.name)}]} />`)}
      </div>`:v=oe`
      <${M} icon="fa-solid fa-database" title="No databases yet"
        action=${oe`
          <${it} variant="primary" onClick=${()=>s(!0)}>
            New database
          <//>`}>
        A database is a SQLite file your apps read and write.
      <//>`,oe`
    <${D} title="Data"
      fab=${{icon:"fa-solid fa-plus",label:"New database",onClick:()=>s(!0)}}>
      <${j} error=${o} onClose=${()=>i(null)} />
      ${v}
    <//>
    <${wn} show=${r} existing=${a??[]}
      onClose=${()=>s(!1)} onCreate=${y} />
    ${l}`}import{html as p,useState as U,useEffect as He,useCallback as gn,useMemo as kn,Button as pe,Dropdown as ie,Table as aa,CheckBox as Sn,TableMaint as Cn}from"acelery/ui.js";import{openDB as xn,deleteDB as Dn}from"acelery/sql.js";var qe=(e,t,a=`${t}s`)=>`${e} ${e===1?t:a}`,En=["INT","DOU","REA","FLO","NUM","DEC","BOO","DAT"],Tn=`create table new_table (
  id integer primary key,
  name text not null
)`,An=200;function na({dbName:e,parts:t,settings:a,updateSettings:n}){let[o,i]=U(null),[r,s]=U("loading"),[c,d]=U(null),[l,u]=U(""),[y,k]=U(null),[v,$]=U([]),m=H(),{confirm:S,dialog:T}=_();He(()=>{let A=!0,P=null;return(async()=>{try{if(!await Rt(e)){A&&s("missing");return}if(P=await xn(e),!A)return;i(P),s("ready"),a["recent.db"]!==e&&n({"recent.db":e})}catch(Z){if(!A)return;d(Z),s("ready")}})(),()=>{A=!1,P?.close().catch(()=>{})}},[e]);async function b(){if(await S(`${e} and every table in it will be deleted. This cannot be undone.`,{title:`Delete ${e}?`,danger:!0,confirmLabel:"Delete"}))try{await o?.close(),await Dn(e),a["recent.db"]===e&&n({"recent.db":""}),m(`Deleted ${e}`),h(["data"],{replace:!0})}catch(P){d(P)}}async function C(A){if(!await S(`The table ${A} and all of its rows will be deleted. This cannot be undone.`,{title:`Drop ${A}?`,danger:!0,confirmLabel:"Drop table"}))return!1;try{return await o.exec(`drop table ${Re(A)}`),m(`Dropped ${A}`),!0}catch(Z){return d(Z),!1}}let[re,he,Ee]=t,ve=p`<${j} error=${c} onClose=${()=>d(null)} />`;if(r==="missing")return p`
      <${D} title=${e} back=${["data"]}>
        <${W} what="Database" action=${p`
          <${pe} variant="primary" onClick=${()=>h(["data"],{replace:!0})}>
            All databases
          <//>`} />
      <//>`;if(re==="table"&&he)return p`
      <${Pn} db=${o} dbName=${e} table=${he} structure=${Ee==="structure"}
        error=${ve} onError=${d}
        onDrop=${async()=>{await C(he)&&h(["data",e],{replace:!0})}} />
      ${T}`;let se=re==="sql"?"sql":"tables";return p`
    <${D} title=${e} back=${["data"]}
      actions=${p`<${ae} title=${e} actions=${[{label:"Delete database",icon:"fa-solid fa-trash",danger:!0,onSelect:b}]} />`}
      subbar=${p`
        <${Fe} label="Database view" value=${se}
          options=${[{value:"tables",label:"Tables",icon:"fa-solid fa-table"},{value:"sql",label:"SQL",icon:"fa-solid fa-terminal"}]}
          onChange=${A=>h(A==="sql"?["data",e,"sql"]:["data",e],{replace:!0})} />`}>
      ${ve}
      ${o?se==="sql"?p`<${In} db=${o} sql=${l} setSql=${u}
                   result=${y} setResult=${k}
                   history=${v} setHistory=${$} />`:p`<${Ln} db=${o} dbName=${e} onError=${d}
                   onDrop=${C}
                   onCreate=${()=>{u(Tn),k(null),h(["data",e,"sql"],{replace:!0})}} />`:r==="loading"?p`<${L} rows=${3} />`:null}
    <//>
    ${T}`}function Ln({db:e,dbName:t,onError:a,onDrop:n,onCreate:o}){let[i,r]=U(null),[s,c]=U({}),d=gn(async()=>{try{let l=await e.select("select name from sqlite_master where type = ? order by name",["table"]);r(l.map(u=>u.name))}catch(l){a(l),r([])}},[e]);return He(()=>{d()},[d]),He(()=>{if(!i)return;let l=!0;return(async()=>{for(let u of i){if(!l)return;try{Re(u);let y=await e.select(`PRAGMA table_info(${u})`),k=await e.selectOne(`select count(*) as n from ${u}`);l&&c(v=>({...v,[u]:{columns:y.length,rows:k?.n??0}}))}catch{}}})(),()=>{l=!1}},[i]),i===null?p`<${L} rows=${3} />`:i.length?p`
    <div class="ac-list">
      ${i.map(l=>{let u=s[l];return p`
          <${q} key=${l} icon="fa-solid fa-table" title=${l}
            meta=${u?`${qe(u.columns,"column")} \xB7 ${qe(u.rows,"row")}`:"\xA0"}
            onOpen=${()=>h(["data",t,"table",l])}
            actions=${[{label:"Structure",icon:"fa-solid fa-table-columns",onSelect:()=>h(["data",t,"table",l,"structure"])},{label:"Drop table",icon:"fa-solid fa-trash",danger:!0,onSelect:async()=>{await n(l)&&d()}}]} />`})}
    </div>`:p`
      <${M} icon="fa-solid fa-table" title="No tables yet"
        action=${p`<${pe} variant="primary" onClick=${o}>Create a table<//>`}>
        Start from a template in the SQL tab.
      <//>`}function Pn({db:e,dbName:t,table:a,structure:n,error:o,onError:i,onDrop:r}){let[s,c]=U(null),[d,l]=U(()=>new Set);He(()=>{if(!e)return;let m=!0;return(async()=>{try{Re(a);let S=await e.select(`PRAGMA table_info(${a})`);m&&c(S)}catch(S){if(!m)return;i(S),c([])}})(),()=>{m=!1}},[e,a]);let u=kn(()=>(s??[]).map(m=>({type:En.some(S=>String(m.type).toUpperCase().includes(S))?"number":"string",title:m.name,name:m.name,inList:!d.has(m.name),inSearch:!0})),[s,d]),y=(m,S)=>l(T=>{let b=new Set(T);return S?b.delete(m):b.add(m),b}),k=p`<${ae} title=${a} actions=${[n?{label:"Browse rows",icon:"fa-solid fa-table",onSelect:()=>h(["data",t,"table",a],{replace:!0})}:{label:"Structure",icon:"fa-solid fa-table-columns",onSelect:()=>h(["data",t,"table",a,"structure"])},{label:"Drop table",icon:"fa-solid fa-trash",danger:!0,onSelect:r}]} />`,v=!n&&s?.length?p`
        <${ie} autoClose="outside" align="end" className="ac-over">
          <${ie.Toggle} as="button" type="button" bsPrefix="ac-chip"
                              aria-label="Choose columns">
            <${g} name="fa-solid fa-table-columns" />
            <span class="d-none d-md-inline">Columns</span>
          <//>
          <${ie.Menu} className="ac-columns-menu" popperConfig=${{strategy:"fixed"}}>
            ${s.map(m=>p`
              <${Sn} key=${m.name} label=${m.name} className="mb-2"
                checked=${!d.has(m.name)}
                onChange=${S=>y(m.name,S)} />`)}
          <//>
        <//>`:null,$;return!e||s===null?$=p`<${L} rows=${4} />`:s.length?n?$=p`
      <div class="ac-results">
        <${aa} hover size="sm">
          <thead>
            <tr><th>Column</th><th>Type</th><th>Not null</th><th>Default</th><th>Key</th></tr>
          </thead>
          <tbody>
            ${s.map(m=>p`
              <tr key=${m.name}>
                <td>${m.name}</td>
                <td>${m.type||p`<span class="ac-null">none</span>`}</td>
                <td>${m.notnull?"yes":""}</td>
                <td>${m.dflt_value??p`<span class="ac-null">NULL</span>`}</td>
                <td>${m.pk?"primary":""}</td>
              </tr>`)}
          </tbody>
        <//>
      </div>`:$=p`
      <${Cn} key=${u.filter(m=>m.inList).map(m=>m.name).join("|")}
        db=${e} title=${a} table=${a} fields=${u} onError=${i} />`:$=p`
      <${W} what="Table" action=${p`
        <${pe} variant="primary"
          onClick=${()=>h(["data",t],{replace:!0})}>
          All tables
        <//>`} />`,p`
    <${D} title=${a}
      subtitle=${n?`Structure \xB7 ${t}`:t}
      back=${n?["data",t,"table",a]:["data",t]}
      actions=${p`${v}${k}`}>
      ${o}
      ${$}
    <//>`}function In({db:e,sql:t,setSql:a,result:n,setResult:o,history:i,setHistory:r}){async function s(){let d=t.trim();if(!d)return;let l=performance.now(),u=()=>Math.max(0,Math.round(performance.now()-l));try{if(/^(select|pragma|with|explain)\b/i.test(d)){let y=await e.select(d);o({kind:"rows",rows:y,ms:u(),limit:An})}else if(/^insert\b/i.test(d)){let y=await e.insert(d);o({kind:"text",text:`Inserted row ${y}`,ms:u()})}else{let y=await e.exec(d);o({kind:"text",text:`${qe(y,"row")} changed`,ms:u()})}r(y=>[d,...y.filter(k=>k!==d)].slice(0,10))}catch(y){o({kind:"error",text:y.message??String(y)})}}let c=null;return n?.kind==="error"?c=p`<${j} error=${n.text} onClose=${()=>o(null)} />`:n?.kind==="text"?c=p`<div class="ac-results-meta" role="status">${n.text} · ${n.ms} ms</div>`:n?.kind==="rows"&&(c=p`<${Fn} result=${n}
      onShowAll=${()=>o({...n,limit:1/0})} />`),p`
    <div class="ac-sql">
      <label class="visually-hidden" for="ac-sql-input">SQL statement</label>
      <textarea id="ac-sql-input" class="form-control ac-sql-input"
        placeholder="select * from …" spellcheck="false" autocapitalize="off"
        autocomplete="off" autocorrect="off" value=${t}
        onInput=${d=>a(d.currentTarget.value)}
        onKeyDown=${d=>{(d.metaKey||d.ctrlKey)&&d.key==="Enter"&&(d.preventDefault(),s())}}></textarea>
      <div class="ac-button-row">
        <${pe} variant="primary" onClick=${s} disabled=${!t.trim()}>
          <${g} name="fa-solid fa-play" /> Run
        <//>
        <${pe} variant="outline-secondary"
          onClick=${()=>{a(""),o(null)}}>
          Clear
        <//>
        ${i.length?p`
              <${ie}>
                <${ie.Toggle} variant="outline-secondary">
                  <${g} name="fa-solid fa-clock-rotate-left" /> History
                <//>
                <${ie.Menu} popperConfig=${{strategy:"fixed"}}>
                  ${i.map(d=>p`
                    <${ie.Item} as="button" key=${d}
                      className="font-monospace text-truncate" style=${{maxWidth:"22rem"}}
                      onClick=${()=>a(d)}>${d}<//>`)}
                <//>
              <//>`:null}
      </div>
      ${c}
    </div>`}function Fn({result:e,onShowAll:t}){let{rows:a,ms:n,limit:o}=e;if(!a.length)return p`<div class="ac-results-meta" role="status">No rows · ${n} ms</div>`;let i=[...new Set(a.flatMap(s=>Object.keys(s)))],r=a.slice(0,o);return p`
    <div class="ac-results-meta" role="status">
      ${qe(a.length,"row")} · ${n} ms
    </div>
    <div class="ac-results">
      <${aa} hover size="sm">
        <thead>
          <tr>${i.map(s=>p`<th key=${s} scope="col">${s}</th>`)}</tr>
        </thead>
        <tbody>
          ${r.map((s,c)=>p`
            <tr key=${c}>
              ${i.map(d=>{let l=s[d];return p`
                  <td key=${d} class=${typeof l=="number"?"ac-num":""}
                      title=${l==null?void 0:String(l)}>
                    ${l==null?p`<span class="ac-null">NULL</span>`:String(l)}
                  </td>`})}
            </tr>`)}
        </tbody>
      <//>
    </div>
    ${a.length>r.length?p`<div>
          <${pe} variant="outline-secondary" onClick=${t}>
            Show all ${a.length}
          <//>
        </div>`:null}`}import{html as _e,useState as Mn,THEMES as jn,applyTheme as oa,currentTheme as ia,currentMode as Bn,themeHasModes as Rn,isDark as ra}from"acelery/ui.js";import{EDITOR_THEMES as On,isDarkTheme as Hn}from"acelery/editor.js";var qn="/system/doc/aCelery-guide.pdf",_n=e=>e.charAt(0).toUpperCase()+e.slice(1),sa=e=>e==="acelery"?"aCelery":_n(e),la="acelery.keepAwake";function Nn(){try{return sessionStorage.getItem(la)==="1"}catch{return!1}}function Un(e){try{sessionStorage.setItem(la,e?"1":"0")}catch{}}function ca({settings:e,updateSettings:t}){let[a,n]=Mn(Nn),o=ia(),i=Rn(o),r=e.editortheme??"";function s(l){t({theme:oa(l)})}function c(l){oa(ia(),{mode:l}),t({"theme.mode":l})}function d(l){n(l),Un(l),G({action:"setKeepAwake",on:l})}return _e`
    <${D} title="Settings">
      <section class="ac-section" aria-labelledby="settings-appearance">
        <h2 class="ac-section-title" id="settings-appearance">Appearance</h2>
        <div class="ac-list">
          <div class="ac-setting">
            <div class="ac-setting-label">
              <span class="ac-setting-name" id="settings-mode">Mode</span>
              <div class="ac-setting-help">
                ${i?"Follow the device, or always light or dark.":`${sa(o)} is always ${ra()?"dark":"light"}.`}
              </div>
            </div>
            <${Fe} role="radiogroup" label="Mode"
              value=${i?Bn():ra()?"dark":"light"}
              onChange=${c}
              options=${[{value:"system",label:"System",icon:"fa-solid fa-circle-half-stroke",disabled:!i},{value:"light",label:"Light",icon:"fa-solid fa-sun",disabled:!i},{value:"dark",label:"Dark",icon:"fa-solid fa-moon",disabled:!i}]} />
          </div>
          <div class="ac-setting">
            <div class="ac-setting-label">
              <label for="settings-theme">Theme</label>
              <div class="ac-setting-help">aCelery and Default follow Mode.</div>
            </div>
            <select id="settings-theme" class="form-select" value=${o}
                    onChange=${l=>s(l.currentTarget.value)}>
              ${jn.map(l=>_e`<option key=${l} value=${l}>${sa(l)}</option>`)}
            </select>
          </div>
          <div class="ac-setting">
            <div class="ac-setting-label">
              <label for="settings-editor">Editor colours</label>
              <div class="ac-setting-help">
                ${r?`A ${Hn(r)?"dark":"light"} scheme, whatever the mode.`:"Light or dark, to match the app."}
              </div>
            </div>
            <select id="settings-editor" class="form-select" value=${r}
                    onChange=${l=>t({editortheme:l.currentTarget.value})}>
              ${On.map(l=>_e`<option key=${l.value} value=${l.value}>${l.label}</option>`)}
            </select>
          </div>
        </div>
      </section>

      ${Q()?_e`
            <section class="ac-section" aria-labelledby="settings-device">
              <h2 class="ac-section-title" id="settings-device">This device</h2>
              <div class="ac-list">
                <${q} icon="fa-solid fa-wifi" title="Network access"
                  meta="Let other devices on your network open aCelery"
                  onOpen=${()=>G({action:"showNetworkAccess"})} />
                <${q} icon="fa-solid fa-box-archive" title="Back up data"
                  meta="Save your databases, files and apps as one zip"
                  onOpen=${()=>G({action:"backupData"})} />
                <${q} icon="fa-solid fa-clock-rotate-left" title="Restore data"
                  meta="Put a backup zip back on this device"
                  onOpen=${()=>G({action:"restoreData"})} />
                <div class="ac-setting">
                  <div class="ac-setting-label">
                    <label for="settings-awake">Keep screen on</label>
                    <div class="ac-setting-help">While aCelery is open</div>
                  </div>
                  <div class="form-check form-switch m-0">
                    <input id="settings-awake" class="form-check-input" type="checkbox"
                      role="switch" checked=${a}
                      onChange=${l=>d(l.currentTarget.checked)} />
                  </div>
                </div>
              </div>
            </section>`:null}

      <section class="ac-section" aria-labelledby="settings-about">
        <h2 class="ac-section-title" id="settings-about">About</h2>
        <div class="ac-list">
          <div class="ac-row">
            <div class="ac-row-icon" aria-hidden="true"><${g} name="fa-solid fa-seedling" /></div>
            <div class="ac-row-body">
              <div class="ac-row-title">aCelery</div>
              <div class="ac-row-meta">Build and run your own JavaScript apps · GPLv3</div>
            </div>
          </div>
          <div class="ac-row">
            <div class="ac-row-icon" aria-hidden="true"><${g} name="fa-solid fa-circle-info" /></div>
            <div class="ac-row-body">
              <div class="ac-row-title">Serving</div>
              <div class="ac-row-meta">${window.location.origin}</div>
            </div>
          </div>
          <div class="ac-row is-action">
            <div class="ac-row-icon" aria-hidden="true">
              <${g} name="fa-solid fa-file-lines" />
            </div>
            <div class="ac-row-body">
              <a class="ac-stretch ac-row-title" href=${qn}
                 target="_blank" rel="noopener">User's guide</a>
              <div class="ac-row-meta">
                ${Q()?"The PDF, opened with your reader":"The PDF, in a new tab"}
              </div>
            </div>
          </div>
          <div class="ac-row is-action">
            <div class="ac-row-icon" aria-hidden="true">
              <${g} name="fa-solid fa-arrow-up-right-from-square" />
            </div>
            <div class="ac-row-body">
              <a class="ac-stretch ac-row-title" href="http://www.acelery.com/"
                 target="_blank" rel="noopener">Website</a>
              <div class="ac-row-meta">www.acelery.com</div>
            </div>
          </div>
        </div>
      </section>
    <//>`}var $a=Promise.resolve();function Wn(e){let t=$a.then(()=>Pt(e));return $a=t.catch(a=>console.error("aCelery: could not save settings",a)),t}function Qn(e){let t=String(e).match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);return t?"#"+t.slice(1,4).map(a=>Number(a).toString(16).padStart(2,"0")).join(""):null}function rt(){Q()&&requestAnimationFrame(()=>{let e=document.querySelector(".ac-appbar")??document.body,t=Qn(getComputedStyle(e).backgroundColor);G({action:"setChrome",dark:ma(),...t?{color:t}:{}})})}function Vn(){let e=bt(),[t,a]=da(null),[,n]=da(0);ua(()=>{Lt().then(u=>{fa(u.theme||"acelery",{mode:u["theme.mode"]||"system"}),a(u)},u=>{console.error("aCelery: could not read settings",u),fa("acelery",{mode:"system"}),a({})})},[]),ua(()=>{let u=()=>{n(k=>k+1),rt()};document.addEventListener("acelery:themechange",u);let y=document.getElementById("xbtheme");return y?.addEventListener("load",rt),()=>{document.removeEventListener("acelery:themechange",u),y?.removeEventListener("load",rt)}},[]);let o=zn(u=>{a(y=>({...y,...u})),Wn(u)},[]);if(!t)return R`
      <${We} section=${e.section}>
        <${D} title="aCelery"><${L} rows=${3} /><//>
      <//>`;let i=t.editortheme,r=i&&Jn.some(u=>u.value===i)?i:ma()?"dark":"light",{section:s,parts:c}=e,d={settings:t,updateSettings:o},l;switch(s){case"home":l=R`<${Ut} ...${d} />`;break;case"apps":l=R`<${zt} ...${d} />`;break;case"code":l=c[0]?R`<${Xt} key=${c[0]} project=${c[0]} fileName=${c[1]}
                 editorTheme=${r} ...${d} />`:R`<${Qt} ...${d} />`;break;case"data":l=c[0]?R`<${na} key=${c[0]} dbName=${c[0]}
                 parts=${c.slice(1)} ...${d} />`:R`<${ta} ...${d} />`;break;case"settings":l=R`<${ca} ...${d} />`;break;default:l=R`
        <${D} title="Not found">
          <${W} what="Page" action=${R`
            <${Gn} variant="primary" onClick=${()=>h([],{replace:!0})}>
              Go home
            <//>`} />
        <//>`}return R`
    <${Dt}>
      <${We} section=${s}>${l}<//>
    <//>`}function Yn(e=document.body){wt(),Kn(R`<${Vn} />`,e)}export{Yn as default};
